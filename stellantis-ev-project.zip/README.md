# v27 Stellantis EV Diagnostic

Ny hovedside: Diagnose.

## GUI
- kjøretøyvelger
- tilkoblingsstatus
- profesjonelt diagnose-dashboard
- live nøkkelverdier
- ECU-scan
- DTC-panel
- batteristatus
- datadekning per profil
- aktivitet/logg

## Kjøretøyprofiler
- Peugeot e-2008 (verifisert grunnprofil i denne appen)
- Peugeot e-208
- Citroën ë-C4
- DS 3 Crossback E-TENSE
- Opel Corsa-e
- Opel Mokka-e
- Jeep Avenger EV
- Peugeot e-Expert / e-Traveller
- Opel/Vauxhall Vivaro-e / Zafira-e Life
- Citroën ë-Jumpy / ë-SpaceTourer
- Toyota Proace Electric
- Opel Astra Electric

Andre modeller enn e-2008 er merket eksperimentelle til ECU/DID-dekning er verifisert.

## DTC
Generisk UDS DTC-lesing er lagt inn for de kartlagte BMS/VCU/OBC-adressene.
Ukjente produsentspesifikke beskrivelser blir ikke funnet på; rå respons beholdes.

Versjon 2.7.0 / versionCode 27.
