# Stellantis EV Diagnostic v28 CLEAN

Denne pakken er laget for å unngå forveksling med eldre e-2008-versjoner.

## Viktig
- Nytt appnavn: `Stellantis EV Diagnostic`
- Ny applicationId: `no.stellantis.evdiagnostic`
- Installeres som en egen app ved siden av den gamle `no.e2008.canlogger`
- Tydelig v28 CLEAN-merke i GUI
- Bygger videre på v27 Stellantis EV GUI

## Innhold
- Stellantis/PSA EV kjøretøyvelger
- Live-data
- Full BMS
- CAN Sniffer
- CAN Decoder
- Semantic Decoder
- ECU-scan
- DTC/feilkodelesing
- temperaturvisning
- balanseringsassistent
- eksport

Versjon 2.8.0 / versionCode 28.
