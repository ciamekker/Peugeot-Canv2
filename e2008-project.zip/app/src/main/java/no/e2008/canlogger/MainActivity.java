package no.e2008.canlogger;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int BT_PERMISSION_REQUEST = 1001;
    private static final UUID SPP_UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private WebView webView;
    private BluetoothAdapter bluetoothAdapter;
    private BluetoothSocket socket;
    private InputStream input;
    private OutputStream output;

    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private volatile boolean monitoring = false;
    private volatile boolean connected = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");

        requestBluetoothPermissionIfNeeded();
    }

    private boolean hasConnectPermission() {
        if (Build.VERSION.SDK_INT < 31) return true;
        return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31 && !hasConnectPermission()) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
            }, BT_PERMISSION_REQUEST);
        }
    }

    private void runJs(String js) {
        mainHandler.post(() -> webView.evaluateJavascript(js, null));
    }

    private void emitStatus(boolean ok, String text) {
        runJs("window.nativeConnectionChanged(" + ok + "," + JSONObject.quote(text) + ");");
    }

    private synchronized void closeSocket() {
        monitoring = false;
        connected = false;
        try { if (input != null) input.close(); } catch (Exception ignored) {}
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        input = null;
        output = null;
        socket = null;
    }

    private void connectToDevice(String address) {
        if (!hasConnectPermission()) {
            requestBluetoothPermissionIfNeeded();
            emitStatus(false, "Bluetooth-tillatelse mangler");
            return;
        }
        if (bluetoothAdapter == null) {
            emitStatus(false, "Bluetooth finnes ikke på enheten");
            return;
        }

        ioExecutor.execute(() -> {
            try {
                closeSocket();
                BluetoothDevice device = bluetoothAdapter.getRemoteDevice(address);

                try {
                    socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                    bluetoothAdapter.cancelDiscovery();
                    socket.connect();
                } catch (Exception secureError) {
                    try { if (socket != null) socket.close(); } catch (Exception ignored) {}
                    socket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
                    socket.connect();
                }

                input = socket.getInputStream();
                output = socket.getOutputStream();
                connected = true;

                String name;
                try { name = device.getName(); }
                catch (SecurityException e) { name = "ELM327"; }
                if (name == null || name.trim().isEmpty()) name = "ELM327";

                emitStatus(true, name);
            } catch (Exception e) {
                closeSocket();
                emitStatus(false, "Tilkobling feilet: " + e.getMessage());
            }
        });
    }

    private String sendElmCommandBlocking(String command, int timeoutMs) throws Exception {
        if (!connected || socket == null || input == null || output == null)
            throw new IllegalStateException("Ikke tilkoblet");

        monitoring = false;

        // drain stale bytes
        try {
            while (input.available() > 0) input.read();
        } catch (Exception ignored) {}

        String normalized = command.replaceAll("\\s+", "") + "\r";
        output.write(normalized.getBytes(StandardCharsets.US_ASCII));
        output.flush();

        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        long deadline = System.currentTimeMillis() + timeoutMs;
        byte[] one = new byte[256];

        while (System.currentTimeMillis() < deadline) {
            int available = input.available();
            if (available > 0) {
                int n = input.read(one, 0, Math.min(one.length, available));
                if (n > 0) {
                    buffer.write(one, 0, n);
                    String current = buffer.toString(StandardCharsets.US_ASCII.name());
                    if (current.indexOf('>') >= 0) return current;
                }
            } else {
                Thread.sleep(12);
            }
        }

        String partial = buffer.toString(StandardCharsets.US_ASCII.name());
        if (!partial.isEmpty()) return partial;
        throw new java.io.IOException("Timeout");
    }

    private boolean isSocketConnected() {
        try {
            return connected
                    && socket != null
                    && socket.isConnected()
                    && input != null
                    && output != null;
        } catch (Exception e) {
            return false;
        }
    }

    private void drainAvailable(int waitMs) {
        if (input == null) return;

        long deadline = System.currentTimeMillis() + Math.max(0, waitMs);

        try {
            while (System.currentTimeMillis() < deadline) {
                int available = input.available();

                if (available > 0) {
                    byte[] buffer = new byte[Math.min(available, 512)];
                    int n = input.read(buffer);
                    if (n < 0) break;
                    // Give the adapter a short quiet period after reading bytes.
                    deadline = System.currentTimeMillis() + 40;
                } else {
                    Thread.sleep(8);
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void startMonitorNative() {
        if (monitoring) return;
        if (!isSocketConnected()) {
            runJs("window.nativeMonitorError(" + JSONObject.quote("Ikke tilkoblet Bluetooth") + ");");
            return;
        }

        ioExecutor.execute(() -> {
            try {
                try {
                    output.write(' ');
                    output.flush();
                    Thread.sleep(120);
                    drainAvailable(250);
                } catch (Exception ignored) {}

                String[] setup = new String[] {
                        "ATPC","ATE0","ATL0","ATS1","ATH1","ATAT1",
                        "ATSP6","ATCAF0","ATCRA"
                };
                for (String cmd : setup) {
                    String r = sendElmCommandBlocking(cmd, 2200);
                    runJs("window.nativeSnifferSetup && window.nativeSnifferSetup(" +
                            JSONObject.quote(cmd) + "," + JSONObject.quote(r) + ");");
                }

                try { sendElmCommandBlocking("0100", 3000); } catch (Exception ignored) {}

                drainAvailable(200);

                // All normal ELM setup commands above use sendElmCommandBlocking(),
                // which intentionally stops monitor mode. Enable monitor mode only now.
                monitoring = true;

                output.write("ATMA\r".getBytes(StandardCharsets.US_ASCII));
                output.flush();
                runJs("window.nativeSnifferStarted && window.nativeSnifferStarted();");

                ByteArrayOutputStream line = new ByteArrayOutputStream();
                long lastDataMs = System.currentTimeMillis();

                while (monitoring && isSocketConnected()) {
                    if (input.available() <= 0) {
                        if (System.currentTimeMillis() - lastDataMs > 5000) {
                            runJs("window.nativeSnifferIdle && window.nativeSnifferIdle();");
                            lastDataMs = System.currentTimeMillis();
                        }
                        Thread.sleep(8);
                        continue;
                    }
                    int b = input.read();
                    if (b < 0) break;
                    lastDataMs = System.currentTimeMillis();
                    if (b == '\r' || b == '\n' || b == '>') {
                        if (line.size() > 0) {
                            String s = line.toString(StandardCharsets.US_ASCII.name()).trim();
                            line.reset();
                            if (!s.isEmpty() && !s.equalsIgnoreCase("ATMA") && !s.equalsIgnoreCase("OK")) {
                                runJs("window.nativeMonitorLine(" + JSONObject.quote(s) + ");");
                            }
                        }
                    } else if (line.size() < 512) {
                        line.write(b);
                    }
                }
            } catch (Exception e) {
                if (monitoring) {
                    runJs("window.nativeMonitorError(" + JSONObject.quote(String.valueOf(e.getMessage())) + ");");
                }
            } finally {
                monitoring = false;
            }
        });
    }

    private void stopMonitorNative() {
        monitoring = false;
        try {
            if (output != null) {
                output.write(' ');
                output.flush();
            }
        } catch (Exception ignored) {}
        ioExecutor.execute(() -> {
            try {
                Thread.sleep(120);
                drainAvailable(500);
                runJs("window.nativeSnifferStopped && window.nativeSnifferStopped();");
            } catch (Exception ignored) {}
        });
    }


    private void exportTextNative(String filename, String mimeType, String content) {
        ioExecutor.execute(() -> {
            String safeName = filename == null ? "e2008_export.txt"
                    : filename.replaceAll("[^A-Za-z0-9._-]", "_");
            String mime = (mimeType == null || mimeType.trim().isEmpty())
                    ? "text/plain" : mimeType;
            String data = content == null ? "" : content;

            try {
                String location;

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                    values.put(MediaStore.MediaColumns.RELATIVE_PATH,
                            Environment.DIRECTORY_DOWNLOADS + "/e2008CAN");
                    values.put(MediaStore.MediaColumns.IS_PENDING, 1);

                    Uri uri = getContentResolver().insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) throw new java.io.IOException("Kunne ikke opprette eksportfil");

                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) throw new java.io.IOException("Kunne ikke åpne eksportfil");
                        os.write(data.getBytes(StandardCharsets.UTF_8));
                        os.flush();
                    }

                    values.clear();
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                    location = uri.toString();
                } else {
                    File base = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (base == null) throw new java.io.IOException("Downloads-mappe utilgjengelig");
                    File dir = new File(base, "e2008CAN");
                    if (!dir.exists() && !dir.mkdirs())
                        throw new java.io.IOException("Kunne ikke opprette eksportmappe");

                    File file = new File(dir, safeName);
                    try (FileOutputStream fos = new FileOutputStream(file)) {
                        fos.write(data.getBytes(StandardCharsets.UTF_8));
                        fos.flush();
                    }
                    location = file.getAbsolutePath();
                }

                runJs("window.nativeExportResult(true," +
                        JSONObject.quote(safeName) + "," +
                        JSONObject.quote(location) + ",null);");
            } catch (Exception e) {
                runJs("window.nativeExportResult(false," +
                        JSONObject.quote(safeName) + ",null," +
                        JSONObject.quote(String.valueOf(e.getMessage())) + ");");
            }
        });
    }

    public class AndroidBridge {

        @JavascriptInterface
        public String platform() {
            return "android-native";
        }

        @JavascriptInterface
        public boolean isConnected() {
            return connected;
        }

        @JavascriptInterface
        public String listBondedDevices() {
            JSONArray arr = new JSONArray();
            try {
                if (!hasConnectPermission()) {
                    requestBluetoothPermissionIfNeeded();
                    return arr.toString();
                }
                if (bluetoothAdapter == null) return arr.toString();

                Set<BluetoothDevice> devices = bluetoothAdapter.getBondedDevices();
                for (BluetoothDevice d : devices) {
                    JSONObject o = new JSONObject();
                    try {
                        o.put("name", d.getName() == null ? "Bluetooth-enhet" : d.getName());
                        o.put("address", d.getAddress());
                        arr.put(o);
                    } catch (Exception ignored) {}
                }
            } catch (Exception ignored) {}
            return arr.toString();
        }

        @JavascriptInterface
        public void requestPermissions() {
            mainHandler.post(MainActivity.this::requestBluetoothPermissionIfNeeded);
        }

        @JavascriptInterface
        public void connect(String address) {
            connectToDevice(address);
        }

        @JavascriptInterface
        public void disconnect() {
            ioExecutor.execute(() -> {
                closeSocket();
                emitStatus(false, "Frakoblet");
            });
        }

        @JavascriptInterface
        public void sendCommand(String requestId, String command, int timeoutMs) {
            ioExecutor.execute(() -> {
                try {
                    String response = sendElmCommandBlocking(command, Math.max(500, timeoutMs));
                    runJs("window.nativeCommandResult(" +
                            JSONObject.quote(requestId) + "," +
                            JSONObject.quote(response) + ",null);");
                } catch (Exception e) {
                    runJs("window.nativeCommandResult(" +
                            JSONObject.quote(requestId) + ",null," +
                            JSONObject.quote(String.valueOf(e.getMessage())) + ");");
                }
            });
        }

        @JavascriptInterface
        public void exportText(String filename, String mimeType, String content) {
            exportTextNative(filename, mimeType, content);
        }

        @JavascriptInterface
        public void startMonitor() {
            startMonitorNative();
        }

        @JavascriptInterface
        public void stopMonitor() {
            stopMonitorNative();
        }
    }

    @Override
    protected void onDestroy() {
        closeSocket();
        ioExecutor.shutdownNow();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
