
const DB=window.E2008_DB;
const $=id=>document.getElementById(id);
const state={connected:false,live:false,initialized:false,monitoring:false,values:{},frames:new Map(),baseline:new Map(),frameCount:0,event:"",eventUntil:0};
const pending=new Map();
let reqSeq=0;

function toast(s){const t=$("toast");t.textContent=s;t.classList.remove("hidden");clearTimeout(window.__tt);window.__tt=setTimeout(()=>t.classList.add("hidden"),2200)}
function log(s){const t=$("terminalLog");t.textContent+=s+"\n";t.scrollTop=t.scrollHeight}
function setStatus(ok,text){state.connected=ok;const b=$("connectBtn");b.className="status "+(ok?"on":"off");b.querySelector("span").textContent=text; if(ok)$("adapterName").textContent=text}

window.nativeConnectionChanged=(ok,text)=>{setStatus(ok,text);toast(text);};
window.nativeCommandResult=(id,response,error)=>{
  const p=pending.get(id);if(!p)return;pending.delete(id);error?p.reject(new Error(error)):p.resolve(response||"");
};
window.nativeMonitorLine=line=>processMonitorLine(line);
window.nativeMonitorError=e=>{state.monitoring=false;toast("Monitor: "+e)};

function nativeCommand(cmd,timeout=1800){
  return new Promise((resolve,reject)=>{
    if(!state.connected)return reject(new Error("Ikke tilkoblet"));
    const id="r"+(++reqSeq);
    pending.set(id,{resolve,reject});
    AndroidBridge.sendCommand(id,cmd,timeout);
    setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error("Timeout"))}},timeout+1500);
  });
}

function openDevices(){
  try{
    AndroidBridge.requestPermissions();
    const arr=JSON.parse(AndroidBridge.listBondedDevices()||"[]");
    const list=$("deviceList");list.innerHTML="";
    if(!arr.length){list.innerHTML='<p>Ingen parede Bluetooth-enheter funnet. Par ELM327 i Android-innstillinger først.</p>'}
    arr.forEach(d=>{
      const b=document.createElement("button");b.className="device";
      b.innerHTML=`<span><strong>${escapeHtml(d.name||"Bluetooth-enhet")}</strong><small>${escapeHtml(d.address)}</small></span><span>›</span>`;
      b.onclick=()=>{AndroidBridge.connect(d.address);$("deviceModal").classList.add("hidden")};
      list.appendChild(b);
    });
    $("deviceModal").classList.remove("hidden");
  }catch(e){toast("Bluetooth-feil: "+e.message)}
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

async function initElm(){
  const cmds=["ATZ","ATE0","ATL0","ATS0","ATSP6","ATCAF1","ATAL","ATST16","ATFCSM1"];
  try{
    for(const c of cmds){log("> "+c);const r=await nativeCommand(c,c==="ATZ"?3000:1800);log(clean(r))}
    state.initialized=true;toast("ELM327 initialisert");
  }catch(e){toast("Init feilet: "+e.message)}
}
function clean(r){return String(r).replace(/\r/g,"\n").replace(/\n+/g,"\n").replace(/>/g,"").trim()}
function hexBytes(s){const m=String(s).match(/[0-9A-Fa-f]{2}/g);return m?m.map(x=>parseInt(x,16)):[]}
function payload(response,did){
  const m=("62"+did).toUpperCase();
  const lines=clean(response).toUpperCase().split(/\n/).map(x=>x.replace(/[^0-9A-F]/g,"")).filter(Boolean);
  for(const l of lines){const i=l.indexOf(m);if(i>=0)return hexBytes(l.slice(i+m.length))}
  const a=lines.join("");const i=a.indexOf(m);return i>=0?hexBytes(a.slice(i+m.length)):null;
}
const u16=(b,o=0)=>((b[o]||0)<<8)|(b[o+1]||0);
const u32=(b,o=0)=>(((b[o]||0)*0x1000000)+((b[o+1]||0)<<16)+((b[o+2]||0)<<8)+(b[o+3]||0))>>>0;
function decode(sig,b){
  if(!b)return null; let v=null;
  if(sig.decode==="u16")v=u16(b,0)*sig.factor+(sig.add||0);
  if(sig.decode==="u16offset1")v=u16(b,1)*sig.factor+(sig.add||0);
  if(sig.decode==="u8")v=(b[0]||0)*sig.factor+(sig.add||0);
  if(sig.decode==="current")v=(76800-u32(b,0))*0.018;
  return Number.isFinite(v)?v:null;
}
async function setupEcu(ecu){
  const e=DB.ecus[ecu];
  await nativeCommand("ATSH"+e.request);
  await nativeCommand("ATFCSH"+e.request);
  await nativeCommand("ATCRA"+e.response);
}
let lastEcu="";
async function readSignal(sig){
  if(lastEcu!==sig.ecu){await setupEcu(sig.ecu);lastEcu=sig.ecu}
  const r=await nativeCommand("22"+sig.did+"1",2200);
  const v=decode(sig,payload(r,sig.did));
  if(v!==null){state.values[sig.key]=v;renderValues()}
}
function fmt(v,d=1){return Number.isFinite(v)?v.toFixed(d):"—"}
function renderValues(){
  const v=state.values;
  $("soc").textContent=fmt(v.soc,1);
  $("hv_voltage").textContent=fmt(v.hv_voltage,1);
  $("hv_current").textContent=fmt(v.hv_current,1);
  $("soh").textContent=fmt(v.soh,1);
  $("cell_min").textContent=fmt(v.cell_min,3);
  $("cell_max").textContent=fmt(v.cell_max,3);
  $("battery_temp").textContent=fmt(v.battery_temp,1);
  $("lv_voltage").textContent=fmt(v.lv_voltage,2);
  $("speed").textContent=fmt(v.speed,0);
  $("rpm").textContent=fmt(v.rpm,0);
  const p=(Number.isFinite(v.hv_voltage)&&Number.isFinite(v.hv_current))?v.hv_voltage*v.hv_current/1000:null;
  $("power").textContent=fmt(p,1);
  const delta=(Number.isFinite(v.cell_min)&&Number.isFinite(v.cell_max))?(v.cell_max-v.cell_min)*1000:null;
  $("cell_delta").textContent=fmt(delta,0);
}
async function liveLoop(){
  while(state.live){
    for(const s of DB.signals){
      if(!state.live)break;
      try{await readSignal(s)}catch(e){log("Poll "+s.name+": "+e.message)}
      await new Promise(r=>setTimeout(r,20));
    }
  }
}
async function toggleLive(){
  if(state.live){state.live=false;$("liveBtn").textContent="Start liveverdier";return}
  if(!state.connected){openDevices();return}
  if(!state.initialized)await initElm();
  state.live=true;$("liveBtn").textContent="Stopp liveverdier";liveLoop();
}

function parseMonitor(line){
  const p=line.trim().toUpperCase().split(/\s+/);
  if(!/^[0-7][0-9A-F]{2}$/.test(p[0]||""))return null;
  const id=p.shift();let dlc=null;
  if(/^[0-8]$/.test(p[0]||""))dlc=parseInt(p.shift());
  const data=p.filter(x=>/^[0-9A-F]{2}$/.test(x));
  if(!data.length)return null;
  return{id,dlc:dlc??data.length,data};
}
function processMonitorLine(line){
  const f=parseMonitor(line);if(!f)return;
  state.frameCount++;
  let s=state.frames.get(f.id);
  const now=performance.now();
  if(!s)s={id:f.id,count:0,first:now,last:now,data:f.data,changes:Array(8).fill(0),prev:null};
  s.count++;s.last=now;
  if(s.prev)for(let i=0;i<Math.min(8,f.data.length);i++)if(s.prev[i]!==f.data[i])s.changes[i]++;
  s.prev=s.data;s.data=f.data;state.frames.set(f.id,s);
  if(state.event && Date.now()<state.eventUntil)s.event=state.event;
  if(state.frameCount%12===0)renderFrames();
}
function changed(s){
  const b=state.baseline.get(s.id);if(!b)return false;
  return s.data.some((x,i)=>b[i]!==x);
}
function renderFrames(){
  const arr=[...state.frames.values()].sort((a,b)=>(changed(b)?1:0)-(changed(a)?1:0)||(b.count-a.count)).slice(0,60);
  $("canRows").innerHTML=arr.map(s=>{
    const sec=(s.last-s.first)/1000;const hz=sec>0?s.count/sec:0;
    return `<div class="canRow ${changed(s)?"changed":""}"><span class="canId">0x${s.id}</span><span class="canData">${s.data.join(" ")}</span><span class="canHz">${hz.toFixed(1)} Hz</span></div>`
  }).join("");
  $("frameCount").textContent=state.frameCount;
  $("idCount").textContent=state.frames.size;
  $("changedCount").textContent=[...state.frames.values()].filter(changed).length;
}
function startMonitor(){
  if(!state.connected){openDevices();return}
  state.live=false;state.monitoring=true;state.frames.clear();state.frameCount=0;AndroidBridge.startMonitor();toast("CAN monitor startet")
}
function stopMonitor(){state.monitoring=false;AndroidBridge.stopMonitor();toast("Monitor stoppet")}
function setBaseline(){state.baseline.clear();for(const [id,s] of state.frames)state.baseline.set(id,[...s.data]);renderFrames();toast("Baseline lagret")}
function markEvent(name){
  state.event=name;state.eventUntil=Date.now()+5000;
  document.querySelectorAll(".events button").forEach(b=>b.classList.toggle("active",b.dataset.event===name));
  toast(name+" markert i 5 sek");
  setTimeout(()=>document.querySelectorAll(".events button").forEach(b=>b.classList.remove("active")),5100);
}
async function terminalSend(cmd){
  if(cmd==="ATMA"){startMonitor();return}
  try{log("> "+cmd);const r=await nativeCommand(cmd,2500);log(clean(r))}catch(e){log("FEIL: "+e.message)}
}

// events
document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>{
  document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x===b));
  document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===b.dataset.page));
});
$("connectBtn").onclick=()=>state.connected?AndroidBridge.disconnect():openDevices();
$("closeModal").onclick=()=>$("deviceModal").classList.add("hidden");
$("initBtn").onclick=()=>state.connected?initElm():openDevices();
$("liveBtn").onclick=toggleLive;
$("monitorBtn").onclick=startMonitor;
$("stopMonitorBtn").onclick=stopMonitor;
$("baselineBtn").onclick=setBaseline;
document.querySelectorAll(".events button").forEach(b=>b.onclick=()=>markEvent(b.dataset.event));
$("terminalSend").onclick=()=>terminalSend($("terminalInput").value.trim());
$("clearTerminal").onclick=()=>$("terminalLog").textContent="";
document.querySelectorAll(".quick button").forEach(b=>b.onclick=()=>terminalSend(b.dataset.cmd));
$("disconnectBtn").onclick=()=>AndroidBridge.disconnect();

try{if(AndroidBridge.isConnected())setStatus(true,"Tilkoblet")}catch(e){}
