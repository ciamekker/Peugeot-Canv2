const DB=window.E2008_DB,$=id=>document.getElementById(id);
const S={connected:false,initialized:false,live:false,values:{},cells:Array(108).fill(null),temps:Array(54).fill(null),lastEcu:""};
const pending=new Map();let seq=0;

function toast(t){let e=$("toast");e.textContent=t;e.classList.remove("hidden");clearTimeout(window.__tt);window.__tt=setTimeout(()=>e.classList.add("hidden"),2200)}
function log(t){let e=$("terminalLog");e.textContent+=(e.textContent?"\n":"")+t;e.scrollTop=e.scrollHeight}
function fmt(v,d=1){return Number.isFinite(v)?v.toFixed(d):"—"}
function set(id,v){let e=$(id);if(e)e.textContent=v}
function setStatus(ok,text){S.connected=ok;let b=$("connectBtn");b.className="status "+(ok?"on":"off");b.querySelector("span").textContent=ok?(text||"Tilkoblet"):"Frakoblet";set("bmsState",ok?"Tilkoblet":"Venter");set("vcuState",ok?"Tilkoblet":"Venter")}
window.nativeConnectionChanged=async(ok,text)=>{
 setStatus(ok,text);toast(text||"Status endret");set("cockpitBtState",ok?(text||"Tilkoblet"):"Frakoblet");
 if(ok){
  S.initialized=false;S.lastEcu="";
  setTimeout(async()=>{
   try{
    await initElm();
    const got=await readFastOnce(true,true);
    if(got===0)toast("Adapter tilkoblet, men ingen ECU-data. Slå på tenningen og trykk Full BMS.");
   }catch(e){log("AUTO INIT FEIL: "+e.message)}
  },350);
 }
};
window.nativeCommandResult=(id,response,error)=>{let p=pending.get(id);if(!p)return;pending.delete(id);error?p.reject(new Error(error)):p.resolve(response||"")};

function nativeCommand(cmd,timeout=2500){return new Promise((resolve,reject)=>{if(!S.connected)return reject(new Error("Ikke tilkoblet"));let id="q"+(++seq);pending.set(id,{resolve,reject});AndroidBridge.sendCommand(id,cmd,timeout);setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error("Timeout"))}},timeout+1600)})}
function clean(r){return String(r).replace(/\r/g,"\n").replace(/>/g,"").replace(/\n+/g,"\n").trim()}
function normalize(r){return clean(r).toUpperCase().split("\n").filter(x=>!x.includes("SEARCHING")&&!x.includes("NO DATA")).map(x=>x.replace(/^\s*[0-9A-F]+\s*:\s*/,"").replace(/[^0-9A-F]/g,"")).join("")}
function hexBytes(h){let a=[];for(let i=0;i+1<h.length;i+=2){let v=parseInt(h.slice(i,i+2),16);if(Number.isFinite(v))a.push(v)}return a}
function payload(r,did){let s=normalize(r),m=("62"+did).toUpperCase(),i=s.indexOf(m);if(i<0)return null;return hexBytes(s.slice(i+m.length))}
const u16=(b,o=0)=>((b[o]||0)<<8)|(b[o+1]||0);
const u32=(b,o=0)=>(((b[o]||0)*16777216)+((b[o+1]||0)<<16)+((b[o+2]||0)<<8)+(b[o+3]||0))>>>0;

function decode(sig,b){
 if(!b)return null;let v=null;
 if(sig.decode==="u16")v=u16(b)*sig.factor+(sig.add||0);
 else if(sig.decode==="u16offset1")v=u16(b,1)*sig.factor+(sig.add||0);
 else if(sig.decode==="u8")v=(b[0]||0)*sig.factor+(sig.add||0);
 else if(sig.decode==="u32")v=u32(b)*sig.factor+(sig.add||0);
 else if(sig.decode==="current")v=(76800-u32(b))*0.018;
 else if(sig.decode==="bool")v=(b[0]||0)?1:0;
 return Number.isFinite(v)?v:null;
}
function decodeArray(sig,b){
 if(!b)return [];
 let out=[];
 if(sig.decode==="array_u16"){for(let i=0;i<sig.count;i++){let o=i*2;if(o+1>=b.length)break;out.push(u16(b,o)*sig.factor+(sig.add||0))}}
 if(sig.decode==="array_u8"){for(let i=0;i<sig.count&&i<b.length;i++)out.push((b[i]||0)*sig.factor+(sig.add||0))}
 return out;
}

async function initElm(){
 const cmds=["ATZ","ATE0","ATL0","ATS0","ATH1","ATAT1","ATSP6","ATCAF1","ATSTFF","ATAL","ATFCSD300000","ATFCSM1"];
 S.initialized=false;S.lastEcu="";
 try{
  for(const c of cmds){log("> "+c);const r=clean(await nativeCommand(c,c==="ATZ"?3500:2200));log(r)}
  try{log("> ATDP");log(clean(await nativeCommand("ATDP",1800)))}catch(e){}
  S.initialized=true;toast("ELM327 / e-CMP klar");
 }catch(e){log("ELM INIT FEIL: "+e.message);toast("ELM init: "+e.message);throw e}
}
async function setupEcu(ecu){
 const e=DB.ecus[ecu];if(!e)throw new Error("Ukjent ECU "+ecu);
 for(const c of ["ATSH"+e.request,"ATFCSH"+e.request,"ATFCSD300000","ATFCSM1","ATCRA"+e.response]){
  try{await nativeCommand(c,1800)}catch(err){log(c+": "+err.message)}
 }
 S.lastEcu=ecu;
}
async function queryDid(sig,timeout){
 if(S.lastEcu!==sig.ecu)await setupEcu(sig.ecu);
 let last="";
 for(const cmd of ["22"+sig.did+"1","22"+sig.did]){
  try{
   const r=await nativeCommand(cmd,timeout);last=r||"";
   const b=payload(last,sig.did);if(b&&b.length)return {response:last,bytes:b,cmd};
  }catch(e){last="FEIL: "+e.message}
 }
 return {response:last,bytes:null,cmd:""};
}
async function readSignal(sig){
 const q=await queryDid(sig,2600);
 if(!q.bytes){log("NO DATA "+sig.name+" ("+sig.did+"): "+clean(q.response).slice(0,120));return false}
 const v=decode(sig,q.bytes);
 if(v!==null&&Number.isFinite(v)){S.values[sig.key]=v;render();return true}
 log("DECODE FEIL "+sig.name+": "+clean(q.response).slice(0,120));return false;
}
async function readArray(sig){
 const q=await queryDid(sig,sig.key==="cells"?12000:7000);
 const arr=decodeArray(sig,q.bytes);
 if(sig.key==="cells"&&arr.length){S.cells=Array(108).fill(null);arr.slice(0,108).forEach((v,i)=>S.cells[i]=v)}
 if(sig.key==="temps"&&arr.length){S.temps=Array(54).fill(null);arr.slice(0,54).forEach((v,i)=>S.temps[i]=v)}
 if(!arr.length)log("NO ARRAY "+sig.name+": "+clean(q.response).slice(0,180));
 render();return arr.length;
}
async function ensureReady(){if(!S.connected){openDevices();return false}if(!S.initialized)await initElm();return true}

async function readFastOnce(silent=false,coreOnly=false){
 if(!await ensureReady())return 0;
 const core=new Set(["soc","hv_voltage","hv_current","cell_min","cell_max","soh","battery_temp","ambient_temp","speed"]);
 let got=0;
 for(const s of DB.signals){
  if(coreOnly&&!core.has(s.key))continue;
  try{if(await readSignal(s))got++}catch(e){log("Les "+s.name+": "+e.message)}
 }
 if(!silent)toast(got?("Leste "+got+" signaler"):"Ingen ECU-svar");
 return got;
}
async function fullRead(){
 if(!await ensureReady())return;
 if(typeof D!=="undefined"&&D.active){try{stopDecode()}catch(e){}}
 S.live=false;toast("Leser full BMS…");
 const got=await readFastOnce(true,false);let arrays=0;
 for(const a of DB.arrays){try{arrays+=await readArray(a)}catch(e){log(a.name+": "+e.message)}}
 if(got===0&&arrays===0)toast("Ingen svar fra bilen – sjekk tenning / Konnwei / OBD.");
 else toast("BMS ferdig: "+got+" signaler, "+arrays+" arrayverdier");
}
async function liveLoop(){
 while(S.live){
  for(const s of DB.signals){if(!S.live)break;try{await readSignal(s)}catch(e){} await new Promise(r=>setTimeout(r,25))}
  slowTick=(window.__slowTick||0)+1;window.__slowTick=slowTick;
  if(slowTick%4===0){try{await readArray(DB.arrays[1])}catch(e){}}
 }
}
async function toggleLive(){
 if(S.live){S.live=false;return}
 if(!await ensureReady())return;
 S.live=true;
 liveLoop();
}

function stats(a){let x=a.filter(Number.isFinite);if(!x.length)return null;return{min:Math.min(...x),max:Math.max(...x),avg:x.reduce((p,c)=>p+c,0)/x.length}}
function render(){
 let v=S.values,p=(Number.isFinite(v.hv_voltage)&&Number.isFinite(v.hv_current))?v.hv_voltage*v.hv_current/1000:null;
 let cs=stats(S.cells),ts=stats(S.temps);
 let delta=cs?(cs.max-cs.min)*1000:(Number.isFinite(v.cell_min)&&Number.isFinite(v.cell_max)?(v.cell_max-v.cell_min)*1000:null);

 set("soc",fmt(v.soc,1));set("soh",fmt(v.soh,1));set("hv_voltage",fmt(v.hv_voltage,1));set("hv_current",fmt(v.hv_current,1));
 set("power",fmt(p,1));set("lv_voltage",fmt(v.lv_voltage,2));set("available_energy",fmt(v.available_energy,1));set("cell_min",fmt(cs?cs.min:v.cell_min,3));
 set("cell_max",fmt(cs?cs.max:v.cell_max,3));set("weak_cell",fmt(v.weak_cell,0));set("battery_temp",fmt(v.battery_temp,1));set("cell_delta",fmt(delta,0));
 set("overviewDelta",fmt(delta,0));set("cellReadCount",S.cells.filter(Number.isFinite).length+" / 108");set("tempReadCount",S.temps.filter(Number.isFinite).length+" / 54");
 let socBarEl=$("socBar");if(socBarEl)socBarEl.style.width=Math.max(0,Math.min(100,v.soc||0))+"%";set("chargeState",v.charge_active===1?"Aktiv":"Ikke aktiv");

 [["b_soc",v.soc,1],["b_soh",v.soh,1],["b_hv",v.hv_voltage,1],["b_current",v.hv_current,1],["b_power",p,1],["b_energy",v.available_energy,1],
 ["b_charge_power",v.charge_power,1],["b_discharge_power",v.discharge_power,1],["b_12v",v.lv_voltage,2],["b_temp",v.battery_temp,1],["b_temp_delta",v.temp_delta,1],
 ["speed",v.speed,0],["rpm",v.rpm,0],["v_soc",v.soc,1],["v_hv",v.hv_voltage,1],["v_power",p,1],["v_12v",v.lv_voltage,2]].forEach(x=>set(x[0],fmt(x[1],x[2])));
 set("b_charge",v.charge_active===1?"Aktiv":"Ikke aktiv");
 set("b_min",fmt(cs?cs.min:v.cell_min,3));set("b_max",fmt(cs?cs.max:v.cell_max,3));set("b_avg",fmt(cs?cs.avg:null,3));set("b_delta",fmt(delta,0));
 set("t_min",fmt(ts?ts.min:null,1));set("t_max",fmt(ts?ts.max:null,1));
 set("overviewMin",cs?fmt(cs.min,3)+" V":"—");set("overviewAvg",cs?fmt(cs.avg,3)+" V":"—");set("overviewMax",cs?fmt(cs.max,3)+" V":"—");
 
 set("liveSoc",fmt(v.soc,1));set("liveHv",fmt(v.hv_voltage,1));set("liveCurrent",fmt(v.hv_current,1));set("livePower",fmt(p,1));
 set("liveSoh",fmt(v.soh,1));set("liveDelta",fmt(delta,0));set("liveMin",fmt(cs?cs.min:v.cell_min,3));set("liveMax",fmt(cs?cs.max:v.cell_max,3));
 set("liveTemp",fmt(v.battery_temp,1));set("live12v",fmt(v.lv_voltage,2));set("liveSpeed",fmt(v.speed,0));set("liveRpm",fmt(v.rpm,0));
 let ring=$("liveSocRing");if(ring)ring.style.setProperty("--soc",Math.max(0,Math.min(100,v.soc||0))+"%");
 // v16 OEM dashboard
 const socVal=Number(v.soc);if(Number.isFinite(socVal)){set("rangeKm",Math.round((socVal/100)*460));const sb=$("socBar");if(sb)sb.style.width=socVal+"%"}
 const sh=$("sohBar");if(sh&&Number.isFinite(v.soh))sh.style.width=Math.max(0,Math.min(100,v.soh))+"%";
 set("hv_current_detail",fmt(v.hv_current,1));set("ambientTempDisplay",Number.isFinite(v.ambient_temp)?fmt(v.ambient_temp,1)+" °C":"— °C");set("bmsTempDisplay",Number.isFinite(v.battery_temp)?fmt(v.battery_temp,1)+" °C":"— °C");set("vcuTempDisplay",Number.isFinite(v.battery_temp)?fmt(v.battery_temp,1)+" °C":"— °C");
 if(ts){set("tempMinCockpit",fmt(ts.min,1)+" °C");set("tempMaxCockpit",fmt(ts.max,1)+" °C");set("tempAvgCockpit",fmt(ts.avg,1)+" °C")}else{set("tempMinCockpit","— °C");set("tempMaxCockpit","— °C");set("tempAvgCockpit",Number.isFinite(v.battery_temp)?fmt(v.battery_temp,1)+" °C":"— °C")}
 set("balanceDeltaCockpit",fmt(delta,0));set("balanceStateCockpit",Number.isFinite(delta)?(delta<=10?"God balanse":delta<=20?"Følg med":"Avvik"):"Venter");
 const validCells=S.cells.filter(Number.isFinite),goodCells=cs?validCells.filter(x=>Math.abs(x-cs.avg)<=0.008).length:0;set("balancedCellsDisplay",goodCells+" / "+validCells.length);set("lastBalanceDisplay",validCells.length?new Date().toLocaleTimeString("no-NO",{hour:"2-digit",minute:"2-digit"}):"—");
 set("vcuState",S.connected?"OK":"Venter");set("bmsState",S.connected?"OK":"Venter");set("cockpitBtState",S.connected?"Tilkoblet":"Frakoblet");set("contactorsState",S.connected?"Lukket":"—");set("isolationState",S.connected?"OK":"—");set("dcdcState",S.connected?"OK":"—");set("coolingState",Number.isFinite(v.battery_temp)&&v.battery_temp>35?"Aktiv":"OK");set("cockpitErrorState","Ingen");
 const pg=$("oemPackGrid");if(pg)pg.innerHTML=Array.from({length:18},(_,i)=>`<div class="pmod" title="Modul ${i+1}"></div>`).join("");
 const mr=$("oemModuleRow");if(mr)mr.innerHTML=Array.from({length:18},(_,m)=>{const t=stats(S.temps.slice(m*3,m*3+3));return `<div class="oem-module"><div class="num">${m+1}</div><div class="stack">${Array.from({length:6},()=>"<i></i>").join("")}</div><div class="temp">${t?fmt(t.avg,0):"—"} °C</div></div>`}).join("");set("moduleCountText","18");set("cellCountText","108");
 const ob=$("oemBars");if(ob)ob.innerHTML=S.cells.map(x=>{if(!Number.isFinite(x))return `<i style="height:18%"></i>`;const h=Math.max(18,Math.min(100,((x-3.35)/(4.25-3.35))*100));const cl=cs&&Math.abs(x-cs.avg)>.015?"warn":"";return `<i class="${cl}" style="height:${h}%"></i>`}).join("");
 const mc=S.cells.slice(0,6),mt=S.temps.slice(0,3),ms=stats(mc),mts=stats(mt),mv=mc.filter(Number.isFinite).reduce((a,b)=>a+b,0);set("cockpitModuleVoltage",ms?fmt(mv,2)+" V":"— V");set("cockpitModuleTemp",mts?fmt(mts.avg,1)+" °C":"— °C");set("cockpitModuleMin",ms?fmt(ms.min,3)+" V":"— V");set("cockpitModuleMax",ms?fmt(ms.max,3)+" V":"— V");set("cockpitModuleDelta",ms?fmt((ms.max-ms.min)*1000,0)+" mV":"— mV");const cd=$("cockpitModuleCells");if(cd)cd.innerHTML=Array.from({length:8},(_,i)=>{const x=mc[i],warn=ms&&Number.isFinite(x)&&Math.abs(x-ms.avg)>.008?"warn":"";return `<div class="cellbox ${warn}"><div class="fill"></div><b>${i+1}<br>${Number.isFinite(x)?fmt(x,3)+" V":"—"}</b></div>`}).join("");
 renderSemantic();
 renderCells(cs);renderModules(cs);
}
function renderCells(cs){
 const ob=$("overviewBars");
 if(ob)ob.innerHTML=S.cells.map(v=>{let h=Number.isFinite(v)?Math.max(12,Math.min(100,((v-3.0)/1.3)*100)):16,cl="";if(Number.isFinite(v)&&cs){let mv=Math.abs(v-cs.avg)*1000;cl=mv>30?"bad":mv>15?"warn":""}return `<i class="${cl}" style="height:${h}%"></i>`}).join("");
 const cg=$("cellsGrid");
 if(cg)cg.innerHTML=S.cells.map((v,i)=>{let h=Number.isFinite(v)?Math.max(12,Math.min(96,((v-3.0)/1.3)*100)):18,cl="";if(Number.isFinite(v)&&cs){let mv=Math.abs(v-cs.avg)*1000;cl=mv>30?"bad":mv>15?"warn":""}return `<div class="cell ${cl}" style="--h:${h}%"><b>#${i+1}</b><small>${Number.isFinite(v)?v.toFixed(3)+" V":"—"}</small></div>`}).join("");
}
function renderModules(cs){
 let mods=[];for(let m=0;m<18;m++){let cells=S.cells.slice(m*6,m*6+6),temps=S.temps.slice(m*3,m*3+3),c=stats(cells),t=stats(temps);let warn=c&&cs&&Math.abs(c.avg-cs.avg)*1000>15;mods.push({m:m+1,cells,temps,c,t,warn})}
 const pm=$("packModules");if(pm)pm.innerHTML=mods.map(x=>`<div class="pack-module ${x.warn?"warn":""}"><b>${x.m}</b></div>`).join("");
 const ms=$("moduleStrip");if(ms)ms.innerHTML=mods.map(x=>`<div class="mod-mini ${x.warn?"warn":""}"><b>M${x.m}</b><div class="mod-batt">${Array(6).fill("<i></i>").join("")}</div><small>${x.t?fmt(x.t.avg,1)+" °C":"—"}</small></div>`).join("");
 const mg=$("modulesGrid");if(mg)mg.innerHTML=mods.map(x=>{let ci=x.cells.map(v=>`<i class="${x.warn?"warn":""}" title="${Number.isFinite(v)?v.toFixed(3):"—"} V"></i>`).join("");let ti=x.temps.map((v,i)=>`<span>T${x.m*3-2+i}: ${Number.isFinite(v)?v.toFixed(1)+"°":"—"}</span>`).join("");let voltage=x.c?x.cells.reduce((a,b)=>a+(Number.isFinite(b)?b:0),0):null;return `<div class="module-detail"><h3>Modul ${x.m} · ${Number.isFinite(voltage)?voltage.toFixed(2)+" V":"—"}</h3><div class="six">${ci}</div><div class="temps">${ti}</div></div>`}).join("");
}

function openDevices(){
 try{
  AndroidBridge.requestPermissions();
  let arr=JSON.parse(AndroidBridge.listBondedDevices()||"[]"),list=$("deviceList");list.innerHTML="";
  if(!arr.length)list.innerHTML="<p>Ingen parede Bluetooth-enheter funnet. Par OBD-adapteren i Android først.</p>";
  arr.forEach(d=>{let b=document.createElement("button");b.className="device";b.innerHTML=`<span><strong>${esc(d.name||"Bluetooth")}</strong><small>${esc(d.address)}</small></span><span>›</span>`;b.onclick=()=>{AndroidBridge.connect(d.address);$("deviceModal").classList.add("hidden")};list.appendChild(b)});
  $("deviceModal").classList.remove("hidden");requestAnimationFrame(()=>list.scrollTop=0);
 }catch(e){toast("Bluetooth: "+e.message)}
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function terminalSend(c){if(!c)return;try{log("> "+c);log(clean(await nativeCommand(c,3000)))}catch(e){log("FEIL: "+e.message)}}


const D={
 active:false,paused:false,changedOnly:false,total:0,rate:0,lastSecond:0,
 ids:new Map(),raw:[],baseline:new Map(),history:new Map(),markerNo:0
};

function parseCanLine(line){
 let s=String(line||"").trim().toUpperCase().replace(/\s+/g," ");
 if(!s||s==="STOPPED")return null;
 if(s.includes("BUFFER FULL"))return {event:"BUFFER FULL"};

 let parts=s.split(" "),id=parts.shift();
 if(!/^[0-9A-F]{3}$/.test(id)&&!/^[0-9A-F]{8}$/.test(id)){
   const compact=s.replace(/\s/g,"");
   const idLen=/^[0-9A-F]{8}/.test(compact)?8:3;
   id=compact.slice(0,idLen);
   if(!/^[0-9A-F]{3}$/.test(id)&&!/^[0-9A-F]{8}$/.test(id))return null;
   parts=(compact.slice(idLen).match(/.{1,2}/g)||[]);
 }
 const bytes=parts.filter(x=>/^[0-9A-F]{2}$/.test(x));
 if(!bytes.length)return null;
 return {id,bytes,dlc:bytes.length,data:bytes.join(" ")};
}

function byteDiff(prev,next){
 const n=Math.max(prev?.length||0,next?.length||0),mask=[];let count=0;
 for(let i=0;i<n;i++){const c=(prev?.[i]||"")!==(next?.[i]||"");mask.push(c);if(c)count++}
 return {mask,count};
}

window.nativeMonitorLine=(line)=>{
 if(!D.active)return;
 const f=parseCanLine(line);if(!f)return;

 if(f.event){
   D.raw.push("! "+new Date().toLocaleTimeString("no-NO")+"  "+f.event);
   if(D.raw.length>600)D.raw.shift();
   set("decodeStatus","Buffer full");renderDecode();return;
 }

 const now=performance.now();
 D.total++;D.lastSecond++;
 const old=D.ids.get(f.id)||{count:0,bytes:[],data:"",dlc:0,ts:now,windowCount:0,rate:0,changeEvents:0,changedMask:[]};
 const diff=byteDiff(old.bytes,f.bytes);
 old.count++;old.windowCount++;old.changeEvents+=diff.count?1:0;old.changedMask=diff.mask;
 old.bytes=f.bytes.slice();old.data=f.data;old.dlc=f.dlc;old.ts=now;D.ids.set(f.id,old);
 const hist=D.history.get(f.id)||[];
 hist.push({t:Date.now(),bytes:f.bytes.slice()});
 if(hist.length>300)hist.shift();
 D.history.set(f.id,hist);

 if(!D.paused){
   const ts=new Date().toLocaleTimeString("no-NO",{hour12:false,hour:"2-digit",minute:"2-digit",second:"2-digit"});
   D.raw.push(ts+"  "+f.id+"  "+f.data);
   if(D.raw.length>600)D.raw.shift();
   renderDecode();
 }
};

window.nativeMonitorError=(e)=>{D.active=false;set("decodeStatus","Feil");toast("CAN Sniffer: "+e);renderDecode()};

function baselineDiff(id,row){const b=D.baseline.get(id);return b?byteDiff(b,row.bytes).count:0}

function renderDecode(){
 set("decodeTotal",String(D.total));set("decodeIds",String(D.ids.size));set("decodeRate",String(D.rate));
 set("decodeStatus",D.active?(D.paused?"Lytter · visning pauset":"Lytter"):"Stoppet");

 const filter=($("decodeFilter")?.value||"").trim().toUpperCase();
 const sort=$("snifferSort")?.value||"rate";
 let rows=[...D.ids.entries()].filter(([id,x])=>{
   if(filter&&!id.includes(filter)&&!x.data.includes(filter))return false;
   if(D.changedOnly&&baselineDiff(id,x)===0&&!(x.changedMask||[]).some(Boolean))return false;
   return true;
 });

 rows.sort((a,b)=>{
   if(sort==="id")return parseInt(a[0],16)-parseInt(b[0],16);
   if(sort==="changed")return (baselineDiff(b[0],b[1])+b[1].changeEvents)-(baselineDiff(a[0],a[1])+a[1].changeEvents);
   if(sort==="recent")return b[1].ts-a[1].ts;
   return (b[1].rate||0)-(a[1].rate||0);
 });

 const now=performance.now(),table=$("canTable");
 if(table)table.innerHTML=rows.map(([id,x])=>{
   const bd=baselineDiff(id,x),bytes=x.bytes.map((byte,i)=>`<span class="sniffer-byte ${x.changedMask?.[i]?"changed":""}">${byte}</span>`).join("");
   const age=Math.max(0,(now-x.ts)/1000);
   return `<div class="sniffer-row ${bd>0?"baseline-diff":""}">
    <span class="canid">${id}</span><span class="rate">${(x.rate||0).toFixed(1)}</span><span class="dlc">${x.dlc}</span>
    <span class="data">${bytes}</span><span class="change-count">${bd||x.changedMask?.filter(Boolean).length||0}</span>
    <span class="count">${x.count}</span><span class="age">${age<1?"<1":age.toFixed(1)}s</span></div>`;
 }).join("");

 const raw=$("decodeRaw");
 if(raw){raw.textContent=D.raw.join("\n");if($("decodeAutoscroll")?.checked)raw.scrollTop=raw.scrollHeight}
 set("rawCountLabel","Siste "+D.raw.length+" meldinger");
}

function startDecode(){
 if(!S.connected){openDevices();return}
 S.live=false;D.active=true;D.paused=false;set("decodeStatus","Starter…");
 AndroidBridge.startMonitor();toast("CAN Sniffer startet · ATMA");
}
function stopDecode(){if(!D.active)return;D.active=false;AndroidBridge.stopMonitor();set("decodeStatus","Stoppet");renderDecode()}

function setSnifferBaseline(){
 D.baseline.clear();for(const [id,row] of D.ids.entries())D.baseline.set(id,row.bytes.slice());
 const t=$("snifferMarkerText");if(t)t.textContent="Baseline: "+D.baseline.size+" CAN-ID";
 toast("Baseline satt");renderDecode();
}
function markSnifferEvent(){
 D.markerNo++;const txt="⚑ EVENT "+D.markerNo+" · "+new Date().toLocaleTimeString("no-NO");
 D.raw.push("========== "+txt+" ==========");if(D.raw.length>600)D.raw.shift();
 const t=$("snifferMarkerText");if(t)t.textContent=txt;renderDecode();
}
setInterval(()=>{
 if(!D.active)return;let total=0;
 for(const [,row] of D.ids.entries()){row.rate=row.windowCount||0;total+=row.rate;row.windowCount=0}
 D.rate=total;D.lastSecond=0;if(!D.paused)renderDecode();
},1000);


function knownCanName(id){
 const map={
  "682":"VCU response",
  "6A2":"VCU request",
  "694":"BMS / TBMU response",
  "6B4":"BMS / TBMU request",
  "58F":"OBC / DC-DC response",
  "590":"OBC / DC-DC request"
 };
 return map[id]||"Ukjent / rå CAN";
}

function s16(v){return v>32767?v-65536:v}
function u16be(a,b){return ((a||0)<<8)|(b||0)}
function u16le(a,b){return ((b||0)<<8)|(a||0)}

function decoderAnalysis(id){
 const row=D.ids.get(id),hist=D.history.get(id)||[];
 if(!row)return null;
 const dlc=row.dlc||row.bytes.length, bytes=[];
 for(let i=0;i<dlc;i++){
   const vals=hist.map(x=>x.bytes[i]).filter(v=>Number.isFinite(v));
   const uniq=[...new Set(vals)];
   let changes=0, bitChanges=Array(8).fill(0);
   for(let j=1;j<vals.length;j++){
     if(vals[j]!==vals[j-1])changes++;
     const x=(vals[j]^vals[j-1])&255;
     for(let b=0;b<8;b++)if(x&(1<<b))bitChanges[b]++;
   }
   const min=vals.length?Math.min(...vals):null,max=vals.length?Math.max(...vals):null;
   const activity=vals.length>1?(changes/(vals.length-1))*100:0;
   let guess="Signal";
   if(uniq.length<=1)guess="Statisk";
   else if(activity>80 && uniq.length>Math.min(20,vals.length*.4))guess="Teller / hurtig signal";
   else if(uniq.length===2)guess="Status / bitfelt";
   else if(activity<10)guess="Langsomt signal";
   bytes.push({i,current:row.bytes[i],min,max,unique:uniq.length,changes,activity,bitChanges,guess});
 }
 const duration=hist.length>1?(hist[hist.length-1].t-hist[0].t)/1000:0;
 return {id,row,hist,bytes,duration};
}

function decoderRanking(){
 return [...D.ids.keys()].map(id=>{
   const a=decoderAnalysis(id);
   const changes=a?a.bytes.reduce((s,b)=>s+b.changes,0):0;
   const active=a?a.bytes.filter(b=>b.changes>0).length:0;
   return {id,row:D.ids.get(id),changes,active,name:knownCanName(id)};
 }).sort((a,b)=>(b.changes+b.active*10)-(a.changes+a.active*10));
}

function populateDecoderIds(){
 const sel=$("decoderIdSelect");if(!sel)return;
 const current=sel.value;
 const ids=[...D.ids.keys()].sort((a,b)=>parseInt(a,16)-parseInt(b,16));
 sel.innerHTML=ids.length?ids.map(id=>`<option value="${id}">${id} · ${knownCanName(id)}</option>`).join(""):'<option value="">Ingen CAN-data ennå</option>';
 if(ids.includes(current))sel.value=current;
}

function renderDecoder(){
 populateDecoderIds();
 const sel=$("decoderIdSelect"),id=sel?.value||[...D.ids.keys()][0];
 const a=id?decoderAnalysis(id):null;

 if(!a){
   set("decoderKnownName","—");set("decoderFrameCount","0");set("decoderDlc","—");set("decoderHz","0 Hz");
   set("decoderCurrent","—");set("decoderDuration","0 s");set("decoderChanges","0");set("decoderActiveBytes","0");
   const ids=["decoderByteTable","decoderWordTable","decoderBitGrid","decoderRanking"];
   ids.forEach(x=>{const el=$(x);if(el)el.innerHTML=""});
   return;
 }

 set("decoderKnownName",knownCanName(id));
 set("decoderFrameCount",String(a.row.count||a.hist.length));
 set("decoderDlc",String(a.row.dlc));
 set("decoderHz",(a.row.rate||0).toFixed(1)+" Hz");
 set("decoderCurrent",a.row.data||"—");
 set("decoderDuration",a.duration.toFixed(1)+" s");
 const totalChanges=a.bytes.reduce((s,b)=>s+b.changes,0);
 set("decoderChanges",String(totalChanges));
 set("decoderActiveBytes",String(a.bytes.filter(b=>b.changes>0).length));

 const bt=$("decoderByteTable");
 if(bt)bt.innerHTML=a.bytes.map(b=>`<div class="decoder-byte-row">
   <span class="byte-id">B${b.i}</span>
   <span>${Number.isFinite(b.current)?b.current:"—"}</span>
   <span>${b.min??"—"}</span><span>${b.max??"—"}</span>
   <span>${b.unique}</span><span>${b.changes}</span>
   <span><span class="activity-bar"><i style="width:${Math.min(100,b.activity).toFixed(0)}%"></i></span></span>
   <span class="guess">${b.guess}</span>
 </div>`).join("");

 const wt=$("decoderWordTable"),cur=a.row.bytes,prev=a.hist.length>1?a.hist[a.hist.length-2].bytes:[];
 if(wt){
   let out="";
   for(let i=0;i<Math.max(0,a.row.dlc-1);i++){
     const be=u16be(cur[i],cur[i+1]),le=u16le(cur[i],cur[i+1]);
     const pbe=u16be(prev[i],prev[i+1]),ple=u16le(prev[i],prev[i+1]);
     out+=`<div class="decoder-word-row">
      <span class="offset">B${i}-${i+1}</span>
      <span>${be}</span><span>${s16(be)}</span><span>${le}</span><span>${s16(le)}</span>
      <span class="delta">${be-pbe}</span><span class="delta">${le-ple}</span>
     </div>`;
   }
   wt.innerHTML=out;
 }

 const bg=$("decoderBitGrid");
 if(bg)bg.innerHTML=a.bytes.map(b=>`<div class="decoder-bit-byte">
   <strong>B${b.i}</strong>
   <div class="decoder-bit-row">${Array.from({length:8},(_,n)=>{
     const bit=7-n, c=b.bitChanges[bit]||0, cls=c>Math.max(8,a.hist.length*.25)?"hot":c>0?"active":"";
     return `<span class="decoder-bit ${cls}" title="${c} endringer">b${bit}</span>`;
   }).join("")}</div>
 </div>`).join("");

 const rank=$("decoderRanking");
 if(rank)rank.innerHTML=decoderRanking().slice(0,30).map(x=>`<div class="decoder-rank-row">
   <b>${x.id}</b><span>${(x.row.rate||0).toFixed(1)}</span><span>${x.row.count}</span>
   <span class="score">${x.changes}</span><span>${x.active}</span><span>${x.name}</span>
 </div>`).join("");
}

function csvCell(v){
 const s=String(v??"");
 return /[",\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;
}
function exportStamp(){
 const d=new Date(),p=n=>String(n).padStart(2,"0");
 return d.getFullYear()+p(d.getMonth()+1)+p(d.getDate())+"_"+p(d.getHours())+p(d.getMinutes())+p(d.getSeconds());
}

window.nativeExportResult=(ok,name,location,error)=>{
 const st=$("exportStatus");
 if(st)st.textContent=ok?("Lagret: "+name):("Eksportfeil: "+(error||"ukjent"));
 toast(ok?("Eksportert "+name):("Eksport feilet: "+(error||"ukjent")));
};

function saveExport(filename,mime,content){
 if(typeof AndroidBridge==="undefined"||!AndroidBridge.exportText){
   toast("Native eksport er ikke tilgjengelig");
   return;
 }
 AndroidBridge.exportText(filename,mime,content);
}

function rawCsvText(){
 const rows=[["timestamp_ms","time","can_id","dlc","data"]];
 for(const [id,h] of D.history.entries()){
   for(const f of h){
     const dt=new Date(f.t);
     rows.push([f.t,dt.toISOString(),id,f.bytes.length,f.bytes.join(" ")]);
   }
 }
 rows.splice(1,rows.length-1,...rows.slice(1).sort((a,b)=>a[0]-b[0]));
 return rows.map(r=>r.map(csvCell).join(",")).join("\n");
}

function decoderCsvText(){
 const rows=[["can_id","known_name","byte","current","min","max","unique_values","changes","activity_pct","guess"]];
 for(const id of [...D.ids.keys()].sort((a,b)=>parseInt(a,16)-parseInt(b,16))){
   const a=decoderAnalysis(id);if(!a)continue;
   for(const b of a.bytes)rows.push([id,knownCanName(id),b.i,b.current,b.min,b.max,b.unique,b.changes,b.activity.toFixed(2),b.guess]);
 }
 return rows.map(r=>r.map(csvCell).join(",")).join("\n");
}

function exportJsonText(){
 const ids={};
 for(const id of D.ids.keys()){
   const a=decoderAnalysis(id);
   ids[id]={
     name:knownCanName(id),
     dlc:a.row.dlc,
     count:a.row.count,
     rate_hz:a.row.rate||0,
     current:a.row.bytes,
     byte_analysis:a.bytes,
     history:a.hist
   };
 }
 return JSON.stringify({
   format:"e2008-can-decoder-v18",
   exported_at:new Date().toISOString(),
   protocol:"ISO 15765-4 CAN 11-bit 500 kbit/s",
   ids
 },null,2);
}

function dbcText(){
 let out='VERSION "e2008 CAN Decoder v18 draft"\\n\\nNS_ :\\n\\nBS_:\\n\\nBU_: Vector__XXX\\n\\n';
 for(const id of [...D.ids.keys()].sort((a,b)=>parseInt(a,16)-parseInt(b,16))){
   const row=D.ids.get(id),dec=parseInt(id,16);
   out+=`BO_ ${dec} CAN_${id}: ${row.dlc} Vector__XXX\\n`;
   for(let i=0;i<row.dlc;i++)out+=` SG_ Byte${i} : ${i*8}|8@1+ (1,0) [0|255] "" Vector__XXX\\n`;
   out+="\\n";
 }
 return out;
}

function exportRawCsv(){saveExport("e2008_raw_"+exportStamp()+".csv","text/csv",rawCsvText())}
function exportDecoderCsv(){saveExport("e2008_decoder_"+exportStamp()+".csv","text/csv",decoderCsvText())}
function exportJson(){saveExport("e2008_can_"+exportStamp()+".json","application/json",exportJsonText())}
function exportDbc(){saveExport("e2008_draft_"+exportStamp()+".dbc","text/plain",dbcText())}



const LEARN={
 baseline:null,
 samples:[],
 maxPerEvent:8
};

function semanticChargingState(){
 const v=S.values;
 const cp=Number(v.charge_power),cur=Number(v.hv_current),active=Number(v.charge_active);
 if(active===1)return {text:"Lading aktiv",detail:Number.isFinite(cp)?fmt(cp,1)+" kW registrert":"OBC melder aktiv lading",cls:"good"};
 if(Number.isFinite(cp)&&cp>0.3)return {text:"Lading aktiv",detail:fmt(cp,1)+" kW",cls:"good"};
 if(Number.isFinite(cur)&&cur< -2)return {text:"Mulig lading",detail:"Negativ batteristrøm "+fmt(cur,1)+" A",cls:"warn"};
 if(active===0)return {text:"Ikke lading",detail:"OBC melder ikke aktiv lading",cls:""};
 return {text:"Ukjent",detail:"Mangler ladestatus",cls:""};
}

function renderSemantic(){
 const v=S.values,cs=stats(S.cells),delta=cs?(cs.max-cs.min)*1000:
   (Number.isFinite(v.cell_min)&&Number.isFinite(v.cell_max)?(v.cell_max-v.cell_min)*1000:null);
 const p=(Number.isFinite(v.hv_voltage)&&Number.isFinite(v.hv_current))?v.hv_voltage*v.hv_current/1000:null;
 const ch=semanticChargingState();

 set("semCharging",ch.text);set("semChargingDetail",ch.detail);
 const semCharge=$("semCharging");if(semCharge)semCharge.className=ch.cls||"";
 set("semSoc",fmt(v.soc,1));set("semVoltage",fmt(v.hv_voltage,1));
 set("semCurrentText",fmt(v.hv_current,1)+" A");
 set("semPower",fmt(p,1));
 set("semPowerMode",Number.isFinite(p)?(p<-.3?"Energi inn / lading":p>.3?"Forbruk / fremdrift":"Nær null effekt"):"Ukjent");
 set("semSoh",fmt(v.soh,1));
 set("semTemp",fmt(v.battery_temp,1));
 set("semTempState",Number.isFinite(v.battery_temp)?(v.battery_temp<5?"Kaldt batteri":v.battery_temp>40?"Høy temperatur":"Normal temperatur"):"Ukjent");
 set("semDriveState",Number(v.speed)>1?"Kjører":"Står stille");
 set("semSpeedText",fmt(v.speed,0)+" km/t");

 if(Number.isFinite(delta)){
   const t=delta<=10?"God":delta<=20?"Følg med":"Høyt avvik";
   set("semBalance",t);set("semBalanceDetail",fmt(delta,0)+" mV mellom min/maks");
 }else{
   set("semBalance","Ukjent");set("semBalanceDetail","Mangler celledata");
 }

 const known=Object.values(v).filter(Number.isFinite).length;
 const validCells=S.cells.filter(Number.isFinite).length;
 set("semanticStatus",(known||validCells)?("Live · "+known+" signaler"):"Venter på data");

 const msgs=[];
 if(ch.text!=="Ukjent")msgs.push({cls:ch.cls||"",text:"<b>Lading:</b> "+ch.text+" · "+ch.detail});
 if(Number.isFinite(v.soc))msgs.push({cls:"good",text:"<b>Batteri:</b> "+fmt(v.soc,1)+" % SOC · "+fmt(v.hv_voltage,1)+" V · "+fmt(v.hv_current,1)+" A"});
 if(Number.isFinite(delta))msgs.push({cls:delta>20?"warn":"good",text:"<b>Celler:</b> "+(cs?fmt(cs.min,3)+"–"+fmt(cs.max,3)+" V":"")+" · avvik "+fmt(delta,0)+" mV"});
 if(Number.isFinite(v.battery_temp))msgs.push({cls:v.battery_temp>40?"warn":"",text:"<b>Temperatur:</b> batteri "+fmt(v.battery_temp,1)+" °C"});
 if(!msgs.length)msgs.push({cls:"",text:"Ingen dekodede BMS/VCU-verdier ennå. Koble til bilen og kjør Full BMS."});

 const box=$("semanticMessages");
 if(box)box.innerHTML=msgs.map(m=>`<div class="semantic-message ${m.cls}">${m.text}</div>`).join("");
}

function snapshotCan(){
 const snap={time:Date.now(),ids:{}};
 for(const [id,row] of D.ids.entries()){
   snap.ids[id]={bytes:(row.bytes||[]).slice(),count:row.count||0,rate:row.rate||0};
 }
 return snap;
}

function takeLearnBaseline(){
 LEARN.baseline=snapshotCan();
 const n=Object.keys(LEARN.baseline.ids).length;
 set("learnState","Baseline: "+n+" CAN-ID");
 toast("Baseline tatt · utfør én handling");
}

function learnEventName(){
 const sel=$("learnEvent"),key=sel?.value||"custom";
 if(key==="custom")return ($("learnCustomName")?.value||"Egendefinert").trim()||"Egendefinert";
 const names={
  charging_on:"Start lading",charging_off:"Stopp lading",brake_on:"Trykk brems",brake_off:"Slipp brems",
  throttle:"Gasspedal",gear_d:"Gir D",gear_r:"Gir R",gear_n:"Gir N",gear_p:"Gir P",
  lights_on:"Lys på",lights_off:"Lys av"
 };
 return names[key]||key;
}

function compareLearnSnapshots(before,after,eventName){
 const candidates=[];
 const allIds=new Set([...Object.keys(before.ids||{}),...Object.keys(after.ids||{})]);

 for(const id of allIds){
   const a=before.ids[id],b=after.ids[id];
   if(!a||!b)continue;
   const n=Math.max(a.bytes.length,b.bytes.length);
   for(let i=0;i<n;i++){
     const av=a.bytes[i]??0,bv=b.bytes[i]??0;
     if(av===bv)continue;

     const xor=(av^bv)&255;
     let bits=0;
     for(let bit=0;bit<8;bit++){
       if(xor&(1<<bit)){
         bits++;
         let score=50;
         if(((av>>bit)&1)!==((bv>>bit)&1))score+=25;
         if((b.rate||0)>0)score+=Math.min(15,b.rate);
         const conf=score>=80?"Høy":score>=60?"Middels":"Lav";
         candidates.push({
           event:eventName,id,loc:"B"+i+" bit "+bit,
           before:(av>>bit)&1,after:(bv>>bit)&1,
           score:Math.round(score),confidence:conf,type:"bit"
         });
       }
     }

     const delta=Math.abs(bv-av);
     let byteScore=35+Math.min(35,delta/4)+Math.min(20,b.rate||0);
     const conf=byteScore>=75?"Høy":byteScore>=55?"Middels":"Lav";
     candidates.push({
       event:eventName,id,loc:"Byte "+i,before:av,after:bv,
       score:Math.round(byteScore),confidence:conf,type:"byte"
     });
   }
 }
 return candidates.sort((a,b)=>b.score-a.score).slice(0,40);
}

function captureLearnEvent(){
 if(!LEARN.baseline){toast("Ta baseline først");return}
 const event=learnEventName(),after=snapshotCan();
 const candidates=compareLearnSnapshots(LEARN.baseline,after,event);
 LEARN.samples.push({time:Date.now(),event,candidates});
 if(LEARN.samples.length>50)LEARN.samples.shift();
 set("learnState",event+" · "+candidates.length+" kandidater");
 renderLearnResults();
 // ny baseline gjør sekvensielle hendelser enklere
 LEARN.baseline=after;
 toast(candidates.length?("Fant "+candidates.length+" kandidater"):"Ingen tydelige endringer");
}

function consolidatedLearnCandidates(){
 const map=new Map();
 for(const s of LEARN.samples){
   for(const c of s.candidates){
     const k=s.event+"|"+c.id+"|"+c.loc+"|"+c.before+"|"+c.after;
     const x=map.get(k)||{...c,hits:0,totalScore:0};
     x.hits++;x.totalScore+=c.score;map.set(k,x);
   }
 }
 return [...map.values()].map(x=>{
   const avg=x.totalScore/x.hits;
   const bonus=Math.min(18,(x.hits-1)*6);
   const score=Math.min(100,Math.round(avg+bonus));
   const confidence=score>=82&&x.hits>=2?"Høy":score>=62?"Middels":"Lav";
   return {...x,score,confidence};
 }).sort((a,b)=>b.score-a.score);
}

function renderLearnResults(){
 const box=$("learnResults");if(!box)return;
 const rows=consolidatedLearnCandidates().slice(0,60);
 if(!rows.length){box.innerHTML='<div class="learn-row"><span>Ingen læring ennå</span><span>—</span><span>—</span><span>—</span><span>—</span><span>—</span></div>';return}
 box.innerHTML=rows.map(r=>{
   const cc=r.confidence==="Høy"?"conf-high":r.confidence==="Middels"?"conf-med":"conf-low";
   return `<div class="learn-row">
    <span>${r.event}</span><span class="id">${r.id}</span><span class="loc">${r.loc}</span>
    <span class="transition">${r.before} → ${r.after}</span><span class="score">${r.score}</span>
    <span class="${cc}">${r.confidence}${r.hits>1?" · "+r.hits+"x":""}</span>
   </div>`;
 }).join("");
}

function clearLearning(){
 LEARN.baseline=null;LEARN.samples=[];set("learnState","Ingen baseline");renderLearnResults();
}

function learnedJsonText(){
 return JSON.stringify({
   format:"e2008-semantic-can-learning-v19",
   exported_at:new Date().toISOString(),
   note:"Kandidater fra hendelsesbasert korrelasjon. Ikke bekreftede Peugeot-signaldefinisjoner.",
   candidates:consolidatedLearnCandidates(),
   samples:LEARN.samples
 },null,2);
}
function learnedCsvText(){
 const rows=[["event","can_id","location","before","after","score","confidence","hits"]];
 for(const r of consolidatedLearnCandidates())rows.push([r.event,r.id,r.loc,r.before,r.after,r.score,r.confidence,r.hits]);
 return rows.map(r=>r.map(csvCell).join(",")).join("\n");
}
function exportLearnedJson(){saveExport("e2008_learned_"+exportStamp()+".json","application/json",learnedJsonText())}
function exportLearnedCsv(){saveExport("e2008_learned_"+exportStamp()+".csv","text/csv",learnedCsvText())}


function buildEmpty(){render()}

function openAppPage(page){
 if(typeof D!=="undefined"&&D.active&&page!=="decode"){try{stopDecode()}catch(e){}}
 document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));
 document.querySelectorAll(".core-nav .nav").forEach(n=>n.classList.toggle("active",n.dataset.page===page));
 document.querySelectorAll(".oem-tabs button").forEach(n=>n.classList.toggle("active",n.dataset.go===page));
 document.body.classList.toggle("bms-mode",["overview","battery","cells","modules","vcu"].includes(page));window.scrollTo(0,0);
}

function bindClick(id,fn){
  const el=document.getElementById(id);
  if(el) el.addEventListener("click",fn);
  return el;
}

// Hovedmeny: Live / Decode / Terminal / Innstillinger
document.querySelectorAll(".core-nav .nav").forEach(btn=>{
  btn.addEventListener("click",ev=>{
    ev.preventDefault();
    openAppPage(btn.dataset.page);
  });
});

// Full BMS og BMS-undermeny
document.querySelectorAll("[data-go]").forEach(btn=>{
  btn.addEventListener("click",ev=>{
    ev.preventDefault();
    ev.stopPropagation();
    openAppPage(btn.dataset.go);
  });
});

const fullBmsOpen=document.getElementById("fullBmsOpen");
if(fullBmsOpen){
  const go=ev=>{
    if(ev){
      ev.preventDefault();
      ev.stopPropagation();
    }
    openAppPage("overview");
  };
  fullBmsOpen.addEventListener("click",go);
  fullBmsOpen.addEventListener("touchend",go,{passive:false});
}

// Bluetooth
bindClick("connectBtn",()=>S.connected?AndroidBridge.disconnect():openDevices());
bindClick("closeModal",()=>{
  const modal=$("deviceModal");
  if(modal) modal.classList.add("hidden");
});
const deviceModal=$("deviceModal");
if(deviceModal){
  deviceModal.addEventListener("click",e=>{
    if(e.target===deviceModal) deviceModal.classList.add("hidden");
  });
}

// Live / diagnostikk
bindClick("liveInitBtn",async()=>{
  if(await ensureReady()){
    await readFastOnce();
    toast("Live-data initialisert");
  }
});
bindClick("batteryReadBtn",readFastOnce);
bindClick("cellsReadBtn",async()=>{
  if(await ensureReady()){
    let n=await readArray(DB.arrays[0]);
    toast("Leste "+n+" celleverdier");
  }
});
bindClick("tempsReadBtn",async()=>{
  if(await ensureReady()){
    let n=await readArray(DB.arrays[1]);
    toast("Leste "+n+" temperaturverdier");
  }
});
bindClick("settingsInit",async()=>{
  if(await ensureReady()) await initElm();
});

// Decode
bindClick("decodeStart",startDecode);
bindClick("decodeStop",stopDecode);
bindClick("decodeClear",()=>{
  D.total=0;D.rate=0;D.ids.clear();D.raw=[];D.baseline.clear();D.history.clear();D.markerNo=0;
  const t=$("snifferMarkerText");if(t)t.textContent="";
  renderDecode();
});
const decodeFilter=$("decodeFilter");
if(decodeFilter) decodeFilter.addEventListener("input",renderDecode);
bindClick("snifferPause",()=>{
 D.paused=!D.paused;
 const b=$("snifferPause");if(b)b.textContent=D.paused?"▶ Fortsett visning":"⏸ Pause visning";
 renderDecode();
});
bindClick("snifferBaseline",setSnifferBaseline);
bindClick("snifferChangedOnly",()=>{
 D.changedOnly=!D.changedOnly;
 const b=$("snifferChangedOnly");if(b)b.textContent="Δ Kun endringer: "+(D.changedOnly?"PÅ":"AV");
 renderDecode();
});
bindClick("snifferMark",markSnifferEvent);
const snifferSort=$("snifferSort");if(snifferSort)snifferSort.addEventListener("change",renderDecode);
bindClick("decoderRefresh",renderDecoder);
const decoderIdSelect=$("decoderIdSelect");if(decoderIdSelect)decoderIdSelect.addEventListener("change",renderDecoder);
bindClick("exportRawCsv",exportRawCsv);
bindClick("exportDecoderCsv",exportDecoderCsv);
bindClick("exportJson",exportJson);
bindClick("exportDbc",exportDbc);

bindClick("learnBaseline",takeLearnBaseline);
bindClick("learnCapture",captureLearnEvent);
bindClick("learnClear",clearLearning);
bindClick("exportLearnedJson",exportLearnedJson);
bindClick("exportLearnedCsv",exportLearnedCsv);
const learnEvent=$("learnEvent");
if(learnEvent)learnEvent.addEventListener("change",()=>{
 const custom=$("learnCustomName");if(custom)custom.classList.toggle("hidden",learnEvent.value!=="custom");
});


// Terminal
bindClick("terminalSend",()=>{
  const input=$("terminalInput");
  if(input) terminalSend(input.value.trim());
});
bindClick("clearTerminal",()=>{
  const term=$("terminalLog");
  if(term) term.textContent="";
});

bindClick("cockpitDisconnect",()=>{try{AndroidBridge.disconnect()}catch(e){}});
bindClick("cockpitFullRead",fullRead);
bindClick("cockpitLiveToggle",async()=>{if(S.live){S.live=false;toast("Live lesing stoppet");return}if(await ensureReady()){S.live=true;liveLoop();toast("Live lesing startet")}});
setInterval(()=>{const c=$("oemClock");if(c)c.textContent=new Date().toLocaleTimeString("no-NO",{hour:"2-digit",minute:"2-digit"})},1000);
// Oppstartsstatus
try{
  if(typeof AndroidBridge!=="undefined" && AndroidBridge.isConnected()){
    setStatus(true,"Tilkoblet");
  }
}catch(e){
  console.log("AndroidBridge status:",e);
}

buildEmpty();renderSemantic();renderLearnResults();
