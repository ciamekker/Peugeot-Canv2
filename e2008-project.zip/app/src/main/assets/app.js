const DB=window.E2008_DB,$=id=>document.getElementById(id);
const S={connected:false,initialized:false,live:false,values:{},cells:Array(108).fill(null),temps:Array(54).fill(null),lastEcu:""};
const pending=new Map();let seq=0;

function toast(t){let e=$("toast");e.textContent=t;e.classList.remove("hidden");clearTimeout(window.__tt);window.__tt=setTimeout(()=>e.classList.add("hidden"),2200)}
function log(t){let e=$("terminalLog");e.textContent+=(e.textContent?"\n":"")+t;e.scrollTop=e.scrollHeight}
function fmt(v,d=1){return Number.isFinite(v)?v.toFixed(d):"—"}
function set(id,v){let e=$(id);if(e)e.textContent=v}
function setStatus(ok,text){S.connected=ok;let b=$("connectBtn");b.className="status "+(ok?"on":"off");b.querySelector("span").textContent=ok?(text||"Tilkoblet"):"Frakoblet";set("bmsState",ok?"Tilkoblet":"Venter");set("vcuState",ok?"Tilkoblet":"Venter")}
window.nativeConnectionChanged=(ok,text)=>{setStatus(ok,text);toast(text||"Status endret")};
window.nativeCommandResult=(id,response,error)=>{let p=pending.get(id);if(!p)return;pending.delete(id);error?p.reject(new Error(error)):p.resolve(response||"")};

function nativeCommand(cmd,timeout=2500){return new Promise((resolve,reject)=>{if(!S.connected)return reject(new Error("Ikke tilkoblet"));let id="q"+(++seq);pending.set(id,{resolve,reject});AndroidBridge.sendCommand(id,cmd,timeout);setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error("Timeout"))}},timeout+1600)})}
function clean(r){return String(r).replace(/\r/g,"\n").replace(/>/g,"").replace(/\n+/g,"\n").trim()}
function normalize(r){return clean(r).toUpperCase().split("\n").filter(x=>!x.includes("SEARCHING")&&!x.includes("NO DATA")).map(x=>x.replace(/^\s*[0-9A-F]+\s*:\s*/,"").replace(/[^0-9A-F]/g,"")).join("")}
function hexBytes(h){let a=[];for(let i=0;i+1<h.length;i+=2){let v=parseInt(h.slice(i,i+2),16);if(Number.isFinite(v))a.push(v)}return a}
function payload(r,did){let s=normalize(r),m=("62"+did).toUpperCase(),i=s.indexOf(m);if(i<0)return null;return hexBytes(s.slice(i+m.length))}
const u16=(b,o=0)=>((b[o]||0)<<8)|(b[o+1]||0);
const u32=(b,o=0)=>(((b[o]||0)*16777216)+((b[o+1]||0)<<16)+((b[o+2]||0)<<8)+(b[o+3]||0))>>>0;

function decode(sig,b){
 if(!b)return null;let v=null;
 if(sig.decode==="u16")v=u16(b)*sig.factor+(sig.add||0);
 else if(sig.decode==="u16offset1")v=u16(b,1)*sig.factor+(sig.add||0);
 else if(sig.decode==="u8")v=(b[0]||0)*sig.factor+(sig.add||0);
 else if(sig.decode==="u32")v=u32(b)*sig.factor+(sig.add||0);
 else if(sig.decode==="current")v=(76800-u32(b))*0.018;
 else if(sig.decode==="bool")v=(b[0]||0)?1:0;
 return Number.isFinite(v)?v:null;
}
function decodeArray(sig,b){
 if(!b)return [];
 let out=[];
 if(sig.decode==="array_u16"){for(let i=0;i<sig.count;i++){let o=i*2;if(o+1>=b.length)break;out.push(u16(b,o)*sig.factor+(sig.add||0))}}
 if(sig.decode==="array_u8"){for(let i=0;i<sig.count&&i<b.length;i++)out.push((b[i]||0)*sig.factor+(sig.add||0))}
 return out;
}

async function initElm(){
 const cmds=["ATZ","ATE0","ATL0","ATS0","ATH0","ATSP6","ATCAF1","ATAL","ATST32"];
 try{for(const c of cmds){log("> "+c);log(clean(await nativeCommand(c,c==="ATZ"?3200:1800)))}S.initialized=true;toast("ELM327 klar")}
 catch(e){toast("ELM init: "+e.message)}
}
async function setupEcu(ecu){
 let e=DB.ecus[ecu];await nativeCommand("ATSH"+e.request);await nativeCommand("ATFCSH"+e.request);await nativeCommand("ATCRA"+e.response);S.lastEcu=ecu;
}
async function readSignal(sig){
 if(S.lastEcu!==sig.ecu)await setupEcu(sig.ecu);
 let r=await nativeCommand("22"+sig.did+"1",2800),v=decode(sig,payload(r,sig.did));
 if(v!==null){S.values[sig.key]=v;render()}
}
async function readArray(sig){
 if(S.lastEcu!==sig.ecu)await setupEcu(sig.ecu);
 let timeout=sig.key==="cells"?7000:4500;
 let r=await nativeCommand("22"+sig.did+"1",timeout),arr=decodeArray(sig,payload(r,sig.did));
 if(sig.key==="cells"&&arr.length){S.cells=Array(108).fill(null);arr.slice(0,108).forEach((v,i)=>S.cells[i]=v)}
 if(sig.key==="temps"&&arr.length){S.temps=Array(54).fill(null);arr.slice(0,54).forEach((v,i)=>S.temps[i]=v)}
 render();return arr.length;
}
async function ensureReady(){if(!S.connected){openDevices();return false}if(!S.initialized)await initElm();return true}

async function readFastOnce(){
 if(!await ensureReady())return;
 for(const s of DB.signals){try{await readSignal(s)}catch(e){log("Les "+s.name+": "+e.message)}}
}
async function fullRead(){
 if(!await ensureReady())return;toast("Leser BMS/VCU…");
 await readFastOnce();
 for(const a of DB.arrays){try{let n=await readArray(a);log(a.name+": "+n+" verdier")}catch(e){log(a.name+": "+e.message)}}
 toast("Full BMS-lesing ferdig");
}
async function liveLoop(){
 while(S.live){
  for(const s of DB.signals){if(!S.live)break;try{await readSignal(s)}catch(e){} await new Promise(r=>setTimeout(r,25))}
  slowTick=(window.__slowTick||0)+1;window.__slowTick=slowTick;
  if(slowTick%4===0){try{await readArray(DB.arrays[1])}catch(e){}}
 }
}
async function toggleLive(){
 if(S.live){S.live=false;$("liveBtn").textContent="▶ Start live";return}
 if(!await ensureReady())return;S.live=true;$("liveBtn").textContent="■ Stopp live";liveLoop();
}

function stats(a){let x=a.filter(Number.isFinite);if(!x.length)return null;return{min:Math.min(...x),max:Math.max(...x),avg:x.reduce((p,c)=>p+c,0)/x.length}}
function render(){
 let v=S.values,p=(Number.isFinite(v.hv_voltage)&&Number.isFinite(v.hv_current))?v.hv_voltage*v.hv_current/1000:null;
 let cs=stats(S.cells),ts=stats(S.temps);
 let delta=cs?(cs.max-cs.min)*1000:(Number.isFinite(v.cell_min)&&Number.isFinite(v.cell_max)?(v.cell_max-v.cell_min)*1000:null);

 set("soc",fmt(v.soc,1));set("soh",fmt(v.soh,1));set("hv_voltage",fmt(v.hv_voltage,1));set("hv_current",fmt(v.hv_current,1));
 set("power",fmt(p,1));set("lv_voltage",fmt(v.lv_voltage,2));set("available_energy",fmt(v.available_energy,1));set("cell_min",fmt(cs?cs.min:v.cell_min,3));
 set("cell_max",fmt(cs?cs.max:v.cell_max,3));set("weak_cell",fmt(v.weak_cell,0));set("battery_temp",fmt(v.battery_temp,1));set("cell_delta",fmt(delta,0));
 set("overviewDelta",fmt(delta,0));set("cellReadCount",S.cells.filter(Number.isFinite).length+" / 108");set("tempReadCount",S.temps.filter(Number.isFinite).length+" / 54");
 $("socBar").style.width=Math.max(0,Math.min(100,v.soc||0))+"%";set("chargeState",v.charge_active===1?"Aktiv":"Ikke aktiv");

 [["b_soc",v.soc,1],["b_soh",v.soh,1],["b_hv",v.hv_voltage,1],["b_current",v.hv_current,1],["b_power",p,1],["b_energy",v.available_energy,1],
 ["b_charge_power",v.charge_power,1],["b_discharge_power",v.discharge_power,1],["b_12v",v.lv_voltage,2],["b_temp",v.battery_temp,1],["b_temp_delta",v.temp_delta,1],
 ["speed",v.speed,0],["rpm",v.rpm,0],["v_soc",v.soc,1],["v_hv",v.hv_voltage,1],["v_power",p,1],["v_12v",v.lv_voltage,2]].forEach(x=>set(x[0],fmt(x[1],x[2])));
 set("b_charge",v.charge_active===1?"Aktiv":"Ikke aktiv");
 set("b_min",fmt(cs?cs.min:v.cell_min,3));set("b_max",fmt(cs?cs.max:v.cell_max,3));set("b_avg",fmt(cs?cs.avg:null,3));set("b_delta",fmt(delta,0));
 set("t_min",fmt(ts?ts.min:null,1));set("t_max",fmt(ts?ts.max:null,1));
 set("overviewMin",cs?fmt(cs.min,3)+" V":"—");set("overviewAvg",cs?fmt(cs.avg,3)+" V":"—");set("overviewMax",cs?fmt(cs.max,3)+" V":"—");
 
 set("liveSoc",fmt(v.soc,1));set("liveHv",fmt(v.hv_voltage,1));set("liveCurrent",fmt(v.hv_current,1));set("livePower",fmt(p,1));
 set("liveSoh",fmt(v.soh,1));set("liveDelta",fmt(delta,0));set("liveMin",fmt(cs?cs.min:v.cell_min,3));set("liveMax",fmt(cs?cs.max:v.cell_max,3));
 set("liveTemp",fmt(v.battery_temp,1));set("live12v",fmt(v.lv_voltage,2));set("liveSpeed",fmt(v.speed,0));set("liveRpm",fmt(v.rpm,0));
 let ring=$("liveSocRing");if(ring)ring.style.setProperty("--soc",Math.max(0,Math.min(100,v.soc||0))+"%");
 renderCells(cs);renderModules(cs);
}
function renderCells(cs){
 let base=cs?cs.avg:3.7;
 $("overviewBars").innerHTML=S.cells.map(v=>{
  let h=Number.isFinite(v)?Math.max(12,Math.min(100,((v-3.0)/1.3)*100)):16,cl="";
  if(Number.isFinite(v)&&cs){let mv=Math.abs(v-cs.avg)*1000;cl=mv>30?"bad":mv>15?"warn":""}
  return `<i class="${cl}" style="height:${h}%"></i>`;
 }).join("");
 $("cellsGrid").innerHTML=S.cells.map((v,i)=>{
  let h=Number.isFinite(v)?Math.max(12,Math.min(96,((v-3.0)/1.3)*100)):18,cl="";
  if(Number.isFinite(v)&&cs){let mv=Math.abs(v-cs.avg)*1000;cl=mv>30?"bad":mv>15?"warn":""}
  return `<div class="cell ${cl}" style="--h:${h}%"><b>#${i+1}</b><small>${Number.isFinite(v)?v.toFixed(3)+" V":"—"}</small></div>`;
 }).join("");
}
function renderModules(cs){
 let mods=[];
 for(let m=0;m<18;m++){
  let cells=S.cells.slice(m*6,m*6+6),temps=S.temps.slice(m*3,m*3+3),c=stats(cells),t=stats(temps);
  let warn=c&&cs&&Math.abs(c.avg-cs.avg)*1000>15;
  mods.push({m:m+1,cells,temps,c,t,warn});
 }
 $("packModules").innerHTML=mods.map(x=>`<div class="pack-module ${x.warn?"warn":""}"><b>${x.m}</b></div>`).join("");
 $("moduleStrip").innerHTML=mods.map(x=>`<div class="mod-mini ${x.warn?"warn":""}"><b>M${x.m}</b><div class="mod-batt">${Array(6).fill("<i></i>").join("")}</div><small>${x.t?fmt(x.t.avg,1)+" °C":"—"}</small></div>`).join("");
 $("modulesGrid").innerHTML=mods.map(x=>{
  let ci=x.cells.map(v=>`<i class="${x.warn?"warn":""}" title="${Number.isFinite(v)?v.toFixed(3):"—"} V"></i>`).join("");
  let ti=x.temps.map((v,i)=>`<span>T${x.m*3-2+i}: ${Number.isFinite(v)?v.toFixed(1)+"°":"—"}</span>`).join("");
  let voltage=x.c?x.cells.reduce((a,b)=>a+(Number.isFinite(b)?b:0),0):null;
  return `<div class="module-detail"><h3>Modul ${x.m} · ${Number.isFinite(voltage)?voltage.toFixed(2)+" V":"—"}</h3><div class="six">${ci}</div><div class="temps">${ti}</div></div>`;
 }).join("");
}

function openDevices(){
 try{
  AndroidBridge.requestPermissions();
  let arr=JSON.parse(AndroidBridge.listBondedDevices()||"[]"),list=$("deviceList");list.innerHTML="";
  if(!arr.length)list.innerHTML="<p>Ingen parede Bluetooth-enheter funnet. Par OBD-adapteren i Android først.</p>";
  arr.forEach(d=>{let b=document.createElement("button");b.className="device";b.innerHTML=`<span><strong>${esc(d.name||"Bluetooth")}</strong><small>${esc(d.address)}</small></span><span>›</span>`;b.onclick=()=>{AndroidBridge.connect(d.address);$("deviceModal").classList.add("hidden")};list.appendChild(b)});
  $("deviceModal").classList.remove("hidden");requestAnimationFrame(()=>list.scrollTop=0);
 }catch(e){toast("Bluetooth: "+e.message)}
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function terminalSend(c){if(!c)return;try{log("> "+c);log(clean(await nativeCommand(c,3000)))}catch(e){log("FEIL: "+e.message)}}


const D={active:false,total:0,rate:0,lastSecond:0,lastTick:Date.now(),ids:new Map(),raw:[]};

function parseCanLine(line){
 let s=String(line||"").trim().toUpperCase().replace(/\s+/g," ");
 if(!s||s==="STOPPED"||s.includes("BUFFER FULL"))return null;
 let p=s.split(" ");
 let id=p.shift();
 if(!/^[0-9A-F]{3}$/.test(id))return null;
 let bytes=p.filter(x=>/^[0-9A-F]{2}$/.test(x));
 if(!bytes.length){
   let compact=s.replace(/\s/g,"");
   id=compact.slice(0,3);
   let rest=compact.slice(3);
   bytes=(rest.match(/.{1,2}/g)||[]).filter(x=>x.length===2);
 }
 return {id,bytes,dlc:bytes.length,data:bytes.join(" ")};
}

window.nativeMonitorLine=(line)=>{
 if(!D.active)return;
 let f=parseCanLine(line);if(!f)return;
 D.total++;D.lastSecond++;
 let old=D.ids.get(f.id)||{count:0,data:"",dlc:0};
 old.count++;old.data=f.data;old.dlc=f.dlc;old.ts=Date.now();D.ids.set(f.id,old);
 D.raw.push(f.id+"  "+f.data);if(D.raw.length>220)D.raw.shift();
 renderDecode();
};
window.nativeMonitorError=(e)=>{D.active=false;set("decodeStatus","Feil");toast("Decode: "+e)};

function renderDecode(){
 set("decodeTotal",String(D.total));set("decodeIds",String(D.ids.size));set("decodeRate",String(D.rate));set("decodeStatus",D.active?"Lytter":"Stoppet");
 let filter=($("decodeFilter")?.value||"").trim().toUpperCase();
 let rows=[...D.ids.entries()].filter(([id,x])=>!filter||id.includes(filter)||x.data.includes(filter)).sort((a,b)=>b[1].ts-a[1].ts);
 let table=$("canTable");if(table)table.innerHTML=rows.map(([id,x])=>`<div class="can-row"><b>${id}</b><span>${x.dlc}</span><code>${x.data}</code><i>${x.count}</i></div>`).join("");
 let raw=$("decodeRaw");if(raw){raw.textContent=D.raw.join("\n");if($("decodeAutoscroll")?.checked)raw.scrollTop=raw.scrollHeight}
}
function startDecode(){
 if(!S.connected){openDevices();return}
 S.live=false;$("liveBtn").textContent="▶ Start live";
 D.active=true;set("decodeStatus","Starter…");AndroidBridge.startMonitor();toast("Rå CAN-monitor startet");
}
function stopDecode(){
 if(!D.active)return;D.active=false;AndroidBridge.stopMonitor();set("decodeStatus","Stoppet");
}
setInterval(()=>{D.rate=D.lastSecond;D.lastSecond=0;renderDecode()},1000);

function buildEmpty(){render()}
document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>{
 if(b.dataset.page!=="decode"&&D.active)stopDecode();
 document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x===b));
 document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===b.dataset.page));
});
document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>document.querySelector(`.nav[data-page="${b.dataset.go}"]`).click());
$("connectBtn").onclick=()=>S.connected?AndroidBridge.disconnect():openDevices();
$("closeModal").onclick=()=>$("deviceModal").classList.add("hidden");
$("deviceModal").onclick=e=>{if(e.target===$("deviceModal"))$("deviceModal").classList.add("hidden")};
$("liveBtn").onclick=toggleLive;$("fullReadBtn").onclick=fullRead;$("batteryReadBtn").onclick=readFastOnce;
$("cellsReadBtn").onclick=async()=>{if(await ensureReady()){let n=await readArray(DB.arrays[0]);toast("Leste "+n+" celleverdier")}};
$("tempsReadBtn").onclick=async()=>{if(await ensureReady()){let n=await readArray(DB.arrays[1]);toast("Leste "+n+" temperaturverdier")}};
$("disconnectBtn").onclick=()=>AndroidBridge.disconnect();
$("terminalSend").onclick=()=>terminalSend($("terminalInput").value.trim());
$("clearTerminal").onclick=()=>$("terminalLog").textContent="";

$("liveInitBtn").onclick=async()=>{if(await ensureReady()){await readFastOnce();toast("Live-data initialisert")}};
$("settingsInit").onclick=async()=>{if(await ensureReady())await initElm()};
$("decodeStart").onclick=startDecode;
$("decodeStop").onclick=stopDecode;
$("decodeClear").onclick=()=>{D.total=0;D.ids.clear();D.raw=[];renderDecode()};
$("decodeFilter").oninput=renderDecode;

try{if(AndroidBridge.isConnected())setStatus(true,"Tilkoblet")}catch(e){}
buildEmpty();

function v11OpenPage(page){
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));
  document.querySelectorAll(".core-nav .nav").forEach(n=>n.classList.toggle("active",n.dataset.page===page));
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll(".core-nav .nav").forEach(b=>b.onclick=()=>{
  if(b.dataset.page!=="decode" && typeof D!=="undefined" && D.active) stopDecode();
  v11OpenPage(b.dataset.page);
});
document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>{
  if(b.dataset.go!=="decode" && typeof D!=="undefined" && D.active) stopDecode();
  v11OpenPage(b.dataset.go);
});


// ===== v12 Full BMS button hard fix =====
function openAppPage(page){
  if(typeof D!=="undefined" && D.active && page!=="decode"){
    try{ stopDecode(); }catch(e){}
  }

  document.querySelectorAll(".page").forEach(p=>{
    p.classList.toggle("active", p.id===page);
  });

  document.querySelectorAll(".core-nav .nav").forEach(n=>{
    n.classList.toggle("active", n.dataset.page===page);
  });

  try{
    window.scrollTo({top:0, behavior:"smooth"});
  }catch(e){
    window.scrollTo(0,0);
  }
}

const fullBmsOpen = document.getElementById("fullBmsOpen");
if(fullBmsOpen){
  fullBmsOpen.onclick = function(ev){
    ev.preventDefault();
    ev.stopPropagation();
    openAppPage("overview");
    return false;
  };

  fullBmsOpen.addEventListener("touchend", function(ev){
    ev.preventDefault();
    ev.stopPropagation();
    openAppPage("overview");
  }, {passive:false});
}

// Replace secondary BMS strip routing with direct page switching.
document.querySelectorAll(".bms-inline-strip [data-go]").forEach(btn=>{
  btn.onclick = function(ev){
    ev.preventDefault();
    ev.stopPropagation();
    openAppPage(btn.dataset.go);
  };
});
