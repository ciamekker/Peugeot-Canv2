const DB=window.E2008_DB,$=id=>document.getElementById(id);
const S={connected:false,initialized:false,live:false,values:{},cells:Array(108).fill(null),temps:Array(54).fill(null),lastEcu:""};
const pending=new Map();let seq=0;

function toast(t){let e=$("toast");e.textContent=t;e.classList.remove("hidden");clearTimeout(window.__tt);window.__tt=setTimeout(()=>e.classList.add("hidden"),2200)}
function log(t){let e=$("terminalLog");e.textContent+=(e.textContent?"\n":"")+t;e.scrollTop=e.scrollHeight}
function fmt(v,d=1){return Number.isFinite(v)?v.toFixed(d):"—"}
function set(id,v){let e=$(id);if(e)e.textContent=v}
function setStatus(ok,text){S.connected=ok;let b=$("connectBtn");b.className="status "+(ok?"on":"off");b.querySelector("span").textContent=ok?(text||"Tilkoblet"):"Frakoblet";set("bmsState",ok?"Tilkoblet":"Venter");set("vcuState",ok?"Tilkoblet":"Venter")}
window.nativeConnectionChanged=async(ok,text)=>{
 setStatus(ok,text);toast(text||"Status endret");set("cockpitBtState",ok?(text||"Tilkoblet"):"Frakoblet");
 if(ok){
  S.initialized=false;S.lastEcu="";
  setTimeout(async()=>{
   try{
    await initElm();
    const got=await readFastOnce(true,true);
    if(got===0)toast("Adapter tilkoblet, men ingen ECU-data. Slå på tenningen og trykk Full BMS.");
   }catch(e){log("AUTO INIT FEIL: "+e.message)}
  },350);
 }
};
window.nativeCommandResult=(id,response,error)=>{let p=pending.get(id);if(!p)return;pending.delete(id);error?p.reject(new Error(error)):p.resolve(response||"")};

function nativeCommand(cmd,timeout=2500){return new Promise((resolve,reject)=>{if(!S.connected)return reject(new Error("Ikke tilkoblet"));let id="q"+(++seq);pending.set(id,{resolve,reject});AndroidBridge.sendCommand(id,cmd,timeout);setTimeout(()=>{if(pending.has(id)){pending.delete(id);reject(new Error("Timeout"))}},timeout+1600)})}
function clean(r){return String(r).replace(/\r/g,"\n").replace(/>/g,"").replace(/\n+/g,"\n").trim()}
function normalize(r){return clean(r).toUpperCase().split("\n").filter(x=>!x.includes("SEARCHING")&&!x.includes("NO DATA")).map(x=>x.replace(/^\s*[0-9A-F]+\s*:\s*/,"").replace(/[^0-9A-F]/g,"")).join("")}
function hexBytes(h){let a=[];for(let i=0;i+1<h.length;i+=2){let v=parseInt(h.slice(i,i+2),16);if(Number.isFinite(v))a.push(v)}return a}
function payload(r,did){let s=normalize(r),m=("62"+did).toUpperCase(),i=s.indexOf(m);if(i<0)return null;return hexBytes(s.slice(i+m.length))}
const u16=(b,o=0)=>((b[o]||0)<<8)|(b[o+1]||0);
const u32=(b,o=0)=>(((b[o]||0)*16777216)+((b[o+1]||0)<<16)+((b[o+2]||0)<<8)+(b[o+3]||0))>>>0;

function decode(sig,b){
 if(!b)return null;let v=null;
 if(sig.decode==="u16")v=u16(b)*sig.factor+(sig.add||0);
 else if(sig.decode==="u16offset1")v=u16(b,1)*sig.factor+(sig.add||0);
 else if(sig.decode==="u8")v=(b[0]||0)*sig.factor+(sig.add||0);
 else if(sig.decode==="u32")v=u32(b)*sig.factor+(sig.add||0);
 else if(sig.decode==="current")v=(76800-u32(b))*0.018;
 else if(sig.decode==="bool")v=(b[0]||0)?1:0;
 return Number.isFinite(v)?v:null;
}
function decodeArray(sig,b){
 if(!b)return [];
 let out=[];
 if(sig.decode==="array_u16"){for(let i=0;i<sig.count;i++){let o=i*2;if(o+1>=b.length)break;out.push(u16(b,o)*sig.factor+(sig.add||0))}}
 if(sig.decode==="array_u8"){for(let i=0;i<sig.count&&i<b.length;i++)out.push((b[i]||0)*sig.factor+(sig.add||0))}
 return out;
}

async function initElm(){
 const cmds=["ATZ","ATE0","ATL0","ATS0","ATH1","ATAT1","ATSP6","ATCAF1","ATSTFF","ATAL","ATFCSD300000","ATFCSM1"];
 S.initialized=false;S.lastEcu="";
 try{
  for(const c of cmds){log("> "+c);const r=clean(await nativeCommand(c,c==="ATZ"?3500:2200));log(r)}
  try{log("> ATDP");log(clean(await nativeCommand("ATDP",1800)))}catch(e){}
  S.initialized=true;toast("ELM327 / e-CMP klar");
 }catch(e){log("ELM INIT FEIL: "+e.message);toast("ELM init: "+e.message);throw e}
}
async function setupEcu(ecu){
 const e=DB.ecus[ecu];if(!e)throw new Error("Ukjent ECU "+ecu);
 for(const c of ["ATSH"+e.request,"ATFCSH"+e.request,"ATFCSD300000","ATFCSM1","ATCRA"+e.response]){
  try{await nativeCommand(c,1800)}catch(err){log(c+": "+err.message)}
 }
 S.lastEcu=ecu;
}
async function queryDid(sig,timeout){
 if(S.lastEcu!==sig.ecu)await setupEcu(sig.ecu);
 let last="";
 for(const cmd of ["22"+sig.did+"1","22"+sig.did]){
  try{
   const r=await nativeCommand(cmd,timeout);last=r||"";
   const b=payload(last,sig.did);if(b&&b.length)return {response:last,bytes:b,cmd};
  }catch(e){last="FEIL: "+e.message}
 }
 return {response:last,bytes:null,cmd:""};
}
async function readSignal(sig){
 const q=await queryDid(sig,2600);
 if(!q.bytes){log("NO DATA "+sig.name+" ("+sig.did+"): "+clean(q.response).slice(0,120));return false}
 const v=decode(sig,q.bytes);
 if(v!==null&&Number.isFinite(v)){S.values[sig.key]=v;render();return true}
 log("DECODE FEIL "+sig.name+": "+clean(q.response).slice(0,120));return false;
}
async function readArray(sig){
 const q=await queryDid(sig,sig.key==="cells"?12000:7000);
 const arr=decodeArray(sig,q.bytes);
 if(sig.key==="cells"&&arr.length){S.cells=Array(108).fill(null);arr.slice(0,108).forEach((v,i)=>S.cells[i]=v)}
 if(sig.key==="temps"&&arr.length){S.temps=Array(54).fill(null);arr.slice(0,54).forEach((v,i)=>S.temps[i]=v)}
 if(!arr.length)log("NO ARRAY "+sig.name+": "+clean(q.response).slice(0,180));
 render();return arr.length;
}
async function ensureReady(){if(!S.connected){openDevices();return false}if(!S.initialized)await initElm();return true}

async function readFastOnce(silent=false,coreOnly=false){
 if(!await ensureReady())return 0;
 const core=new Set(["soc","hv_voltage","hv_current","cell_min","cell_max","soh","battery_temp","ambient_temp","speed"]);
 let got=0;
 for(const s of DB.signals){
  if(coreOnly&&!core.has(s.key))continue;
  try{if(await readSignal(s))got++}catch(e){log("Les "+s.name+": "+e.message)}
 }
 if(!silent)toast(got?("Leste "+got+" signaler"):"Ingen ECU-svar");
 return got;
}
async function fullRead(){
 if(!await ensureReady())return;
 if(typeof D!=="undefined"&&D.active){try{stopDecode()}catch(e){}}
 S.live=false;toast("Leser full BMS…");
 const got=await readFastOnce(true,false);let arrays=0;
 for(const a of DB.arrays){try{arrays+=await readArray(a)}catch(e){log(a.name+": "+e.message)}}
 if(got===0&&arrays===0)toast("Ingen svar fra bilen – sjekk tenning / Konnwei / OBD.");
 else toast("BMS ferdig: "+got+" signaler, "+arrays+" arrayverdier");
}
async function liveLoop(){
 while(S.live){
  for(const s of DB.signals){if(!S.live)break;try{await readSignal(s)}catch(e){} await new Promise(r=>setTimeout(r,25))}
  slowTick=(window.__slowTick||0)+1;window.__slowTick=slowTick;
  if(slowTick%4===0){try{await readArray(DB.arrays[1])}catch(e){}}
 }
}
async function toggleLive(){
 if(S.live){S.live=false;return}
 if(!await ensureReady())return;
 S.live=true;
 liveLoop();
}

function stats(a){let x=a.filter(Number.isFinite);if(!x.length)return null;return{min:Math.min(...x),max:Math.max(...x),avg:x.reduce((p,c)=>p+c,0)/x.length}}
function render(){
 let v=S.values,p=(Number.isFinite(v.hv_voltage)&&Number.isFinite(v.hv_current))?v.hv_voltage*v.hv_current/1000:null;
 let cs=stats(S.cells),ts=stats(S.temps);
 let delta=cs?(cs.max-cs.min)*1000:(Number.isFinite(v.cell_min)&&Number.isFinite(v.cell_max)?(v.cell_max-v.cell_min)*1000:null);

 set("soc",fmt(v.soc,1));set("soh",fmt(v.soh,1));set("hv_voltage",fmt(v.hv_voltage,1));set("hv_current",fmt(v.hv_current,1));
 set("power",fmt(p,1));set("lv_voltage",fmt(v.lv_voltage,2));set("available_energy",fmt(v.available_energy,1));set("cell_min",fmt(cs?cs.min:v.cell_min,3));
 set("cell_max",fmt(cs?cs.max:v.cell_max,3));set("weak_cell",fmt(v.weak_cell,0));set("battery_temp",fmt(v.battery_temp,1));set("cell_delta",fmt(delta,0));
 set("overviewDelta",fmt(delta,0));set("cellReadCount",S.cells.filter(Number.isFinite).length+" / 108");set("tempReadCount",S.temps.filter(Number.isFinite).length+" / 54");
 let socBarEl=$("socBar");if(socBarEl)socBarEl.style.width=Math.max(0,Math.min(100,v.soc||0))+"%";set("chargeState",v.charge_active===1?"Aktiv":"Ikke aktiv");

 [["b_soc",v.soc,1],["b_soh",v.soh,1],["b_hv",v.hv_voltage,1],["b_current",v.hv_current,1],["b_power",p,1],["b_energy",v.available_energy,1],
 ["b_charge_power",v.charge_power,1],["b_discharge_power",v.discharge_power,1],["b_12v",v.lv_voltage,2],["b_temp",v.battery_temp,1],["b_temp_delta",v.temp_delta,1],
 ["speed",v.speed,0],["rpm",v.rpm,0],["v_soc",v.soc,1],["v_hv",v.hv_voltage,1],["v_power",p,1],["v_12v",v.lv_voltage,2]].forEach(x=>set(x[0],fmt(x[1],x[2])));
 set("b_charge",v.charge_active===1?"Aktiv":"Ikke aktiv");
 set("b_min",fmt(cs?cs.min:v.cell_min,3));set("b_max",fmt(cs?cs.max:v.cell_max,3));set("b_avg",fmt(cs?cs.avg:null,3));set("b_delta",fmt(delta,0));
 set("t_min",fmt(ts?ts.min:null,1));set("t_max",fmt(ts?ts.max:null,1));
 set("overviewMin",cs?fmt(cs.min,3)+" V":"—");set("overviewAvg",cs?fmt(cs.avg,3)+" V":"—");set("overviewMax",cs?fmt(cs.max,3)+" V":"—");
 
 set("liveSoc",fmt(v.soc,1));set("liveHv",fmt(v.hv_voltage,1));set("liveCurrent",fmt(v.hv_current,1));set("livePower",fmt(p,1));
 set("liveSoh",fmt(v.soh,1));set("liveDelta",fmt(delta,0));set("liveMin",fmt(cs?cs.min:v.cell_min,3));set("liveMax",fmt(cs?cs.max:v.cell_max,3));
 set("liveTemp",fmt(v.battery_temp,1));set("live12v",fmt(v.lv_voltage,2));set("liveSpeed",fmt(v.speed,0));set("liveRpm",fmt(v.rpm,0));
 let ring=$("liveSocRing");if(ring)ring.style.setProperty("--soc",Math.max(0,Math.min(100,v.soc||0))+"%");
 // v16 OEM dashboard
 const socVal=Number(v.soc);if(Number.isFinite(socVal)){set("rangeKm",Math.round((socVal/100)*460));const sb=$("socBar");if(sb)sb.style.width=socVal+"%"}
 const sh=$("sohBar");if(sh&&Number.isFinite(v.soh))sh.style.width=Math.max(0,Math.min(100,v.soh))+"%";
 set("hv_current_detail",fmt(v.hv_current,1));set("ambientTempDisplay",Number.isFinite(v.ambient_temp)?fmt(v.ambient_temp,1)+" °C":"— °C");set("bmsTempDisplay",Number.isFinite(v.battery_temp)?fmt(v.battery_temp,1)+" °C":"— °C");set("vcuTempDisplay",Number.isFinite(v.battery_temp)?fmt(v.battery_temp,1)+" °C":"— °C");
 if(ts){set("tempMinCockpit",fmt(ts.min,1)+" °C");set("tempMaxCockpit",fmt(ts.max,1)+" °C");set("tempAvgCockpit",fmt(ts.avg,1)+" °C")}else{set("tempMinCockpit","— °C");set("tempMaxCockpit","— °C");set("tempAvgCockpit",Number.isFinite(v.battery_temp)?fmt(v.battery_temp,1)+" °C":"— °C")}
 set("balanceDeltaCockpit",fmt(delta,0));set("balanceStateCockpit",Number.isFinite(delta)?(delta<=10?"God balanse":delta<=20?"Følg med":"Avvik"):"Venter");
 const validCells=S.cells.filter(Number.isFinite),goodCells=cs?validCells.filter(x=>Math.abs(x-cs.avg)<=0.008).length:0;set("balancedCellsDisplay",goodCells+" / "+validCells.length);set("lastBalanceDisplay",validCells.length?new Date().toLocaleTimeString("no-NO",{hour:"2-digit",minute:"2-digit"}):"—");
 set("vcuState",S.connected?"OK":"Venter");set("bmsState",S.connected?"OK":"Venter");set("cockpitBtState",S.connected?"Tilkoblet":"Frakoblet");set("contactorsState",S.connected?"Lukket":"—");set("isolationState",S.connected?"OK":"—");set("dcdcState",S.connected?"OK":"—");set("coolingState",Number.isFinite(v.battery_temp)&&v.battery_temp>35?"Aktiv":"OK");set("cockpitErrorState","Ingen");
 const pg=$("oemPackGrid");if(pg)pg.innerHTML=Array.from({length:18},(_,i)=>`<div class="pmod" title="Modul ${i+1}"></div>`).join("");
 const mr=$("oemModuleRow");if(mr)mr.innerHTML=Array.from({length:18},(_,m)=>{const t=stats(S.temps.slice(m*3,m*3+3));return `<div class="oem-module"><div class="num">${m+1}</div><div class="stack">${Array.from({length:6},()=>"<i></i>").join("")}</div><div class="temp">${t?fmt(t.avg,0):"—"} °C</div></div>`}).join("");set("moduleCountText","18");set("cellCountText","108");
 const ob=$("oemBars");if(ob)ob.innerHTML=S.cells.map(x=>{if(!Number.isFinite(x))return `<i style="height:18%"></i>`;const h=Math.max(18,Math.min(100,((x-3.35)/(4.25-3.35))*100));const cl=cs&&Math.abs(x-cs.avg)>.015?"warn":"";return `<i class="${cl}" style="height:${h}%"></i>`}).join("");
 const mc=S.cells.slice(0,6),mt=S.temps.slice(0,3),ms=stats(mc),mts=stats(mt),mv=mc.filter(Number.isFinite).reduce((a,b)=>a+b,0);set("cockpitModuleVoltage",ms?fmt(mv,2)+" V":"— V");set("cockpitModuleTemp",mts?fmt(mts.avg,1)+" °C":"— °C");set("cockpitModuleMin",ms?fmt(ms.min,3)+" V":"— V");set("cockpitModuleMax",ms?fmt(ms.max,3)+" V":"— V");set("cockpitModuleDelta",ms?fmt((ms.max-ms.min)*1000,0)+" mV":"— mV");const cd=$("cockpitModuleCells");if(cd)cd.innerHTML=Array.from({length:8},(_,i)=>{const x=mc[i],warn=ms&&Number.isFinite(x)&&Math.abs(x-ms.avg)>.008?"warn":"";return `<div class="cellbox ${warn}"><div class="fill"></div><b>${i+1}<br>${Number.isFinite(x)?fmt(x,3)+" V":"—"}</b></div>`}).join("");
 renderCells(cs);renderModules(cs);
}
function renderCells(cs){
 const ob=$("overviewBars");
 if(ob)ob.innerHTML=S.cells.map(v=>{let h=Number.isFinite(v)?Math.max(12,Math.min(100,((v-3.0)/1.3)*100)):16,cl="";if(Number.isFinite(v)&&cs){let mv=Math.abs(v-cs.avg)*1000;cl=mv>30?"bad":mv>15?"warn":""}return `<i class="${cl}" style="height:${h}%"></i>`}).join("");
 const cg=$("cellsGrid");
 if(cg)cg.innerHTML=S.cells.map((v,i)=>{let h=Number.isFinite(v)?Math.max(12,Math.min(96,((v-3.0)/1.3)*100)):18,cl="";if(Number.isFinite(v)&&cs){let mv=Math.abs(v-cs.avg)*1000;cl=mv>30?"bad":mv>15?"warn":""}return `<div class="cell ${cl}" style="--h:${h}%"><b>#${i+1}</b><small>${Number.isFinite(v)?v.toFixed(3)+" V":"—"}</small></div>`}).join("");
}
function renderModules(cs){
 let mods=[];for(let m=0;m<18;m++){let cells=S.cells.slice(m*6,m*6+6),temps=S.temps.slice(m*3,m*3+3),c=stats(cells),t=stats(temps);let warn=c&&cs&&Math.abs(c.avg-cs.avg)*1000>15;mods.push({m:m+1,cells,temps,c,t,warn})}
 const pm=$("packModules");if(pm)pm.innerHTML=mods.map(x=>`<div class="pack-module ${x.warn?"warn":""}"><b>${x.m}</b></div>`).join("");
 const ms=$("moduleStrip");if(ms)ms.innerHTML=mods.map(x=>`<div class="mod-mini ${x.warn?"warn":""}"><b>M${x.m}</b><div class="mod-batt">${Array(6).fill("<i></i>").join("")}</div><small>${x.t?fmt(x.t.avg,1)+" °C":"—"}</small></div>`).join("");
 const mg=$("modulesGrid");if(mg)mg.innerHTML=mods.map(x=>{let ci=x.cells.map(v=>`<i class="${x.warn?"warn":""}" title="${Number.isFinite(v)?v.toFixed(3):"—"} V"></i>`).join("");let ti=x.temps.map((v,i)=>`<span>T${x.m*3-2+i}: ${Number.isFinite(v)?v.toFixed(1)+"°":"—"}</span>`).join("");let voltage=x.c?x.cells.reduce((a,b)=>a+(Number.isFinite(b)?b:0),0):null;return `<div class="module-detail"><h3>Modul ${x.m} · ${Number.isFinite(voltage)?voltage.toFixed(2)+" V":"—"}</h3><div class="six">${ci}</div><div class="temps">${ti}</div></div>`}).join("");
}

function openDevices(){
 try{
  AndroidBridge.requestPermissions();
  let arr=JSON.parse(AndroidBridge.listBondedDevices()||"[]"),list=$("deviceList");list.innerHTML="";
  if(!arr.length)list.innerHTML="<p>Ingen parede Bluetooth-enheter funnet. Par OBD-adapteren i Android først.</p>";
  arr.forEach(d=>{let b=document.createElement("button");b.className="device";b.innerHTML=`<span><strong>${esc(d.name||"Bluetooth")}</strong><small>${esc(d.address)}</small></span><span>›</span>`;b.onclick=()=>{AndroidBridge.connect(d.address);$("deviceModal").classList.add("hidden")};list.appendChild(b)});
  $("deviceModal").classList.remove("hidden");requestAnimationFrame(()=>list.scrollTop=0);
 }catch(e){toast("Bluetooth: "+e.message)}
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function terminalSend(c){if(!c)return;try{log("> "+c);log(clean(await nativeCommand(c,3000)))}catch(e){log("FEIL: "+e.message)}}


const D={
 active:false,paused:false,changedOnly:false,total:0,rate:0,lastSecond:0,
 ids:new Map(),raw:[],baseline:new Map(),markerNo:0
};

function parseCanLine(line){
 let s=String(line||"").trim().toUpperCase().replace(/\s+/g," ");
 if(!s||s==="STOPPED")return null;
 if(s.includes("BUFFER FULL"))return {event:"BUFFER FULL"};

 let parts=s.split(" "),id=parts.shift();
 if(!/^[0-9A-F]{3}$/.test(id)&&!/^[0-9A-F]{8}$/.test(id)){
   const compact=s.replace(/\s/g,"");
   const idLen=/^[0-9A-F]{8}/.test(compact)?8:3;
   id=compact.slice(0,idLen);
   if(!/^[0-9A-F]{3}$/.test(id)&&!/^[0-9A-F]{8}$/.test(id))return null;
   parts=(compact.slice(idLen).match(/.{1,2}/g)||[]);
 }
 const bytes=parts.filter(x=>/^[0-9A-F]{2}$/.test(x));
 if(!bytes.length)return null;
 return {id,bytes,dlc:bytes.length,data:bytes.join(" ")};
}

function byteDiff(prev,next){
 const n=Math.max(prev?.length||0,next?.length||0),mask=[];let count=0;
 for(let i=0;i<n;i++){const c=(prev?.[i]||"")!==(next?.[i]||"");mask.push(c);if(c)count++}
 return {mask,count};
}

window.nativeMonitorLine=(line)=>{
 if(!D.active)return;
 const f=parseCanLine(line);if(!f)return;

 if(f.event){
   D.raw.push("! "+new Date().toLocaleTimeString("no-NO")+"  "+f.event);
   if(D.raw.length>600)D.raw.shift();
   set("decodeStatus","Buffer full");renderDecode();return;
 }

 const now=performance.now();
 D.total++;D.lastSecond++;
 const old=D.ids.get(f.id)||{count:0,bytes:[],data:"",dlc:0,ts:now,windowCount:0,rate:0,changeEvents:0,changedMask:[]};
 const diff=byteDiff(old.bytes,f.bytes);
 old.count++;old.windowCount++;old.changeEvents+=diff.count?1:0;old.changedMask=diff.mask;
 old.bytes=f.bytes.slice();old.data=f.data;old.dlc=f.dlc;old.ts=now;D.ids.set(f.id,old);

 if(!D.paused){
   const ts=new Date().toLocaleTimeString("no-NO",{hour12:false,hour:"2-digit",minute:"2-digit",second:"2-digit"});
   D.raw.push(ts+"  "+f.id+"  "+f.data);
   if(D.raw.length>600)D.raw.shift();
   renderDecode();
 }
};

window.nativeMonitorError=(e)=>{D.active=false;set("decodeStatus","Feil");toast("CAN Sniffer: "+e);renderDecode()};

function baselineDiff(id,row){const b=D.baseline.get(id);return b?byteDiff(b,row.bytes).count:0}

function renderDecode(){
 set("decodeTotal",String(D.total));set("decodeIds",String(D.ids.size));set("decodeRate",String(D.rate));
 set("decodeStatus",D.active?(D.paused?"Lytter · visning pauset":"Lytter"):"Stoppet");

 const filter=($("decodeFilter")?.value||"").trim().toUpperCase();
 const sort=$("snifferSort")?.value||"rate";
 let rows=[...D.ids.entries()].filter(([id,x])=>{
   if(filter&&!id.includes(filter)&&!x.data.includes(filter))return false;
   if(D.changedOnly&&baselineDiff(id,x)===0&&!(x.changedMask||[]).some(Boolean))return false;
   return true;
 });

 rows.sort((a,b)=>{
   if(sort==="id")return parseInt(a[0],16)-parseInt(b[0],16);
   if(sort==="changed")return (baselineDiff(b[0],b[1])+b[1].changeEvents)-(baselineDiff(a[0],a[1])+a[1].changeEvents);
   if(sort==="recent")return b[1].ts-a[1].ts;
   return (b[1].rate||0)-(a[1].rate||0);
 });

 const now=performance.now(),table=$("canTable");
 if(table)table.innerHTML=rows.map(([id,x])=>{
   const bd=baselineDiff(id,x),bytes=x.bytes.map((byte,i)=>`<span class="sniffer-byte ${x.changedMask?.[i]?"changed":""}">${byte}</span>`).join("");
   const age=Math.max(0,(now-x.ts)/1000);
   return `<div class="sniffer-row ${bd>0?"baseline-diff":""}">
    <span class="canid">${id}</span><span class="rate">${(x.rate||0).toFixed(1)}</span><span class="dlc">${x.dlc}</span>
    <span class="data">${bytes}</span><span class="change-count">${bd||x.changedMask?.filter(Boolean).length||0}</span>
    <span class="count">${x.count}</span><span class="age">${age<1?"<1":age.toFixed(1)}s</span></div>`;
 }).join("");

 const raw=$("decodeRaw");
 if(raw){raw.textContent=D.raw.join("\n");if($("decodeAutoscroll")?.checked)raw.scrollTop=raw.scrollHeight}
 set("rawCountLabel","Siste "+D.raw.length+" meldinger");
}

function startDecode(){
 if(!S.connected){openDevices();return}
 S.live=false;D.active=true;D.paused=false;set("decodeStatus","Starter…");
 AndroidBridge.startMonitor();toast("CAN Sniffer startet · ATMA");
}
function stopDecode(){if(!D.active)return;D.active=false;AndroidBridge.stopMonitor();set("decodeStatus","Stoppet");renderDecode()}

function setSnifferBaseline(){
 D.baseline.clear();for(const [id,row] of D.ids.entries())D.baseline.set(id,row.bytes.slice());
 const t=$("snifferMarkerText");if(t)t.textContent="Baseline: "+D.baseline.size+" CAN-ID";
 toast("Baseline satt");renderDecode();
}
function markSnifferEvent(){
 D.markerNo++;const txt="⚑ EVENT "+D.markerNo+" · "+new Date().toLocaleTimeString("no-NO");
 D.raw.push("========== "+txt+" ==========");if(D.raw.length>600)D.raw.shift();
 const t=$("snifferMarkerText");if(t)t.textContent=txt;renderDecode();
}
setInterval(()=>{
 if(!D.active)return;let total=0;
 for(const [,row] of D.ids.entries()){row.rate=row.windowCount||0;total+=row.rate;row.windowCount=0}
 D.rate=total;D.lastSecond=0;if(!D.paused)renderDecode();
},1000);

function buildEmpty(){render()}

function openAppPage(page){
 if(typeof D!=="undefined"&&D.active&&page!=="decode"){try{stopDecode()}catch(e){}}
 document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===page));
 document.querySelectorAll(".core-nav .nav").forEach(n=>n.classList.toggle("active",n.dataset.page===page));
 document.querySelectorAll(".oem-tabs button").forEach(n=>n.classList.toggle("active",n.dataset.go===page));
 document.body.classList.toggle("bms-mode",["overview","battery","cells","modules","vcu"].includes(page));window.scrollTo(0,0);
}

function bindClick(id,fn){
  const el=document.getElementById(id);
  if(el) el.addEventListener("click",fn);
  return el;
}

// Hovedmeny: Live / Decode / Terminal / Innstillinger
document.querySelectorAll(".core-nav .nav").forEach(btn=>{
  btn.addEventListener("click",ev=>{
    ev.preventDefault();
    openAppPage(btn.dataset.page);
  });
});

// Full BMS og BMS-undermeny
document.querySelectorAll("[data-go]").forEach(btn=>{
  btn.addEventListener("click",ev=>{
    ev.preventDefault();
    ev.stopPropagation();
    openAppPage(btn.dataset.go);
  });
});

const fullBmsOpen=document.getElementById("fullBmsOpen");
if(fullBmsOpen){
  const go=ev=>{
    if(ev){
      ev.preventDefault();
      ev.stopPropagation();
    }
    openAppPage("overview");
  };
  fullBmsOpen.addEventListener("click",go);
  fullBmsOpen.addEventListener("touchend",go,{passive:false});
}

// Bluetooth
bindClick("connectBtn",()=>S.connected?AndroidBridge.disconnect():openDevices());
bindClick("closeModal",()=>{
  const modal=$("deviceModal");
  if(modal) modal.classList.add("hidden");
});
const deviceModal=$("deviceModal");
if(deviceModal){
  deviceModal.addEventListener("click",e=>{
    if(e.target===deviceModal) deviceModal.classList.add("hidden");
  });
}

// Live / diagnostikk
bindClick("liveInitBtn",async()=>{
  if(await ensureReady()){
    await readFastOnce();
    toast("Live-data initialisert");
  }
});
bindClick("batteryReadBtn",readFastOnce);
bindClick("cellsReadBtn",async()=>{
  if(await ensureReady()){
    let n=await readArray(DB.arrays[0]);
    toast("Leste "+n+" celleverdier");
  }
});
bindClick("tempsReadBtn",async()=>{
  if(await ensureReady()){
    let n=await readArray(DB.arrays[1]);
    toast("Leste "+n+" temperaturverdier");
  }
});
bindClick("settingsInit",async()=>{
  if(await ensureReady()) await initElm();
});

// Decode
bindClick("decodeStart",startDecode);
bindClick("decodeStop",stopDecode);
bindClick("decodeClear",()=>{
  D.total=0;D.rate=0;D.ids.clear();D.raw=[];D.baseline.clear();D.markerNo=0;
  const t=$("snifferMarkerText");if(t)t.textContent="";
  renderDecode();
});
const decodeFilter=$("decodeFilter");
if(decodeFilter) decodeFilter.addEventListener("input",renderDecode);
bindClick("snifferPause",()=>{
 D.paused=!D.paused;
 const b=$("snifferPause");if(b)b.textContent=D.paused?"▶ Fortsett visning":"⏸ Pause visning";
 renderDecode();
});
bindClick("snifferBaseline",setSnifferBaseline);
bindClick("snifferChangedOnly",()=>{
 D.changedOnly=!D.changedOnly;
 const b=$("snifferChangedOnly");if(b)b.textContent="Δ Kun endringer: "+(D.changedOnly?"PÅ":"AV");
 renderDecode();
});
bindClick("snifferMark",markSnifferEvent);
const snifferSort=$("snifferSort");if(snifferSort)snifferSort.addEventListener("change",renderDecode);

// Terminal
bindClick("terminalSend",()=>{
  const input=$("terminalInput");
  if(input) terminalSend(input.value.trim());
});
bindClick("clearTerminal",()=>{
  const term=$("terminalLog");
  if(term) term.textContent="";
});

bindClick("cockpitDisconnect",()=>{try{AndroidBridge.disconnect()}catch(e){}});
bindClick("cockpitFullRead",fullRead);
bindClick("cockpitLiveToggle",async()=>{if(S.live){S.live=false;toast("Live lesing stoppet");return}if(await ensureReady()){S.live=true;liveLoop();toast("Live lesing startet")}});
setInterval(()=>{const c=$("oemClock");if(c)c.textContent=new Date().toLocaleTimeString("no-NO",{hour:"2-digit",minute:"2-digit"})},1000);
// Oppstartsstatus
try{
  if(typeof AndroidBridge!=="undefined" && AndroidBridge.isConnected()){
    setStatus(true,"Tilkoblet");
  }
}catch(e){
  console.log("AndroidBridge status:",e);
}

buildEmpty();
