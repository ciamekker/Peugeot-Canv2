# e-2008 CAN v9 – Live + Decode + Full BMS

Sammenslått Android-versjon.

Beholder:
- Live-siden
- Decode / rå CAN-monitor
- Terminal
- Innstillinger

Legger til:
- Full BMS-oversikt
- Batteri
- 108 cellegrupper
- 18 moduler
- 54 temperaturpunkter
- VCU-side

Decode bruker native ELM327 ATMA-monitor via Bluetooth Classic SPP.
Full BMS/Live er read-only diagnostikk.
