# e-2008 CAN v19 – Semantic CAN Decoder

Bygger videre på v18 CAN Decoder + Export.

## Ren norsk tekst
Kjente e-CMP/BMS/VCU-verdier vises som menneskelesbar status:
- Lading aktiv / ikke lading / mulig lading
- SOC
- HV-spenning og batteristrøm
- effekt og retning
- SOH
- cellebalanse / mV-avvik
- batteritemperatur
- kjører / står stille

## Lær ukjente CAN-signaler
Hendelsesbasert læring:
1. Ta baseline.
2. Utfør én handling.
3. Registrer hendelsen.
4. Appen rangerer CAN-ID / byte / bit som endret seg.

Forhåndsvalg:
- Start / stopp lading
- trykk / slipp brems
- gasspedal
- gir P/N/R/D
- lys på / av
- egendefinert hendelse

Kandidater vises med score og Lav / Middels / Høy sikkerhet.
Høy sikkerhet krever gjentatte like observasjoner. Resultatene er korrelasjoner og
må verifiseres før de behandles som ekte signaldefinisjoner.

## Eksport
- RAW CSV
- Decoder CSV
- komplett JSON
- DBC-utkast
- lærte signaler JSON
- lærte signaler CSV

Versjon 2.1.0 / versionCode 19.
