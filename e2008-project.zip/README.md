# e-2008 CAN v14 – Cockpit BMS

Full BMS-siden er bygget om til et cockpit-dashboard inspirert av referansebildet.

## Full BMS-layout
- Venstre: SoC, SOH, HV-spenning, strøm, effekt, 12 V og energi
- Midten: visuell e-CMP batteripakke med 18 moduler
- Høyre: temperaturer og cellebalanse
- Modulrad med 18 moduler
- 108 cellegrupper som stolpediagram
- ModuldetaIjer, celledetaljer og systemstatus nederst
- Fast handlingslinje med Koble fra / Live / Full BMS / Terminal

## Beholdt
- Live
- Decode
- Terminal
- Innstillinger
- Batteri
- Celler
- Moduler
- VCU
- Bluetooth Classic / ELM327

Mobilvisningen stabler dashboardet vertikalt uten å gjøre teksten mikroskopisk.

Versjon 1.6.0 / versionCode 14.
