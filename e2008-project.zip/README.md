# e-2008 CAN v12 – Full BMS Button Fix

Fix:
- Full BMS-knappen har nå egen ID og direkte click-handler.
- Touch-handler lagt til for Android WebView.
- Knappen ligger over vanlig innholdslag og har eksplisitt pointer-events.
- Ekstra avstand mot fast bunnmeny slik at den ikke overlapper.
- BMS-undermeny bruker direkte sidebytte.

Beholder:
- Live
- Decode
- Terminal
- Innstillinger
- Oversikt
- Batteri
- Celler
- Moduler
- VCU

Versjon: 1.5.1 / versionCode 12
