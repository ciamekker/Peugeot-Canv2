# e-2008 CAN v15 – OEM Dashboard

Denne versjonen gjør Full BMS / Oversikt mye nærmere referansebildet.

## Endringer
- Ny OEM-lignende toppbar
- Venstre fast sidepanel med SoC, rekkevidde, HV-data og SOH
- Midtseksjon med stor kjøretøy/batterivisning
- Høyre paneler for temperatur og balansering
- Modulrad under kjøretøyet
- Stort celle-diagram med sideverdier
- Nederst: moduldetaljer, celledetaljer og systemstatus
- Fast handlingslinje nederst

## Beholdt
- Live
- Decode
- Terminal
- Innstillinger
- Batteri
- Celler
- Moduler
- VCU

Versjon 1.7.0 / versionCode 15
