# e-2008 CAN v17 – CAN Sniffer

Bygger videre på v16 CLEAN DATA FIX.

## CAN Sniffer
Native ELM327/KONNWEI sniffing via Bluetooth Classic og `ATMA` (Monitor All).

Viser:
- CAN-ID
- DLC
- payload bytes
- Hz / meldinger per sekund per CAN-ID
- totalt antall meldinger
- antall unike CAN-ID-er
- endrede bytes markert
- alder siden sist sett
- baseline / sammenligning mot baseline
- filter på CAN-ID eller payload
- sortering på rate, endringer, CAN-ID eller sist sett
- pause av UI uten å stoppe monitor
- kun endrede CAN-ID-er
- hendelsesmarkører i råloggen
- BUFFER FULL vises tydelig

Live/BMS polling stoppes automatisk mens ATMA kjører.

Merk: ELM327/KONNWEI kan miste frames på en travel CAN-buss. Dedikert USB-CAN er bedre for tapsfri logging.

Versjon 1.9.0 / versionCode 17.
