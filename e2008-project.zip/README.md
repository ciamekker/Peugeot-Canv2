# e-2008 CAN v23 – Android Socket Fix

Denne versjonen retter Codemagic-feilen:

`BluetoothSocket` har ikke metoden `isClosed()`.

`isSocketConnected()` bruker nå kun gyldige Android API-er:
- `socket != null`
- `socket.isConnected()`
- `input != null`
- `output != null`
- intern `connected`-status

Sniffer-fiksene fra v22 er beholdt.

Versjon: 2.3.2 / versionCode 23
