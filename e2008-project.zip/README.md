# e-2008 CAN v21 – OEM Full BMS

Full BMS-siden er bygd på nytt med teknisk batteripakke, 18 moduler, 108 cellegrupper, temperatur, balanse, systemstatus og detaljkort. Beholder Live, Sniffer, Decoder, Semantic Decoder og eksport.

Versjon 2.3.0 / versionCode 21.
