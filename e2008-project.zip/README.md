# e-2008 CAN v11 – First Draft Live

v11 keeps the first Live / Decode / Terminal / Settings workflow and places Full BMS as separate subpages.

Core pages:
- Live
- Decode
- Terminal
- Settings

Full BMS pages:
- Oversikt
- Batteri
- Celler
- Moduler
- VCU

Live page was redesigned to closely match the first concept:
- Large circular SOC meter
- HV voltage / current / power
- BMS / VCU Drivlinje section
- SOH, cell delta, min/max, temperature, 12V, speed, RPM
- Fixed bottom navigation
- Dedicated Full BMS button

Version: 1.5.0 / versionCode 11
