# e-2008 CAN v13 – Navigation Fix

Dette retter den egentlige Full BMS-feilen.

Årsaken var at app.js fortsatt refererte til tre knapper som ikke lenger finnes i v11-layouten:
- liveBtn
- fullReadBtn
- disconnectBtn

JavaScript stoppet under oppstart før Full BMS-handleren ble registrert.

v13:
- alle gamle knappereferanser fjernet
- UI-bindinger er null-safe
- Full BMS bruker direkte click + touch
- BMS-undermenyer bruker openAppPage()
- alle JavaScript-ID-er er kontrollert mot HTML
- Live, Decode, Terminal og Innstillinger beholdt
- Full BMS-sidene beholdt

Versjon 1.5.2 / versionCode 13
