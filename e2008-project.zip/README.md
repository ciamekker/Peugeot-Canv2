# e-2008 CAN – Codemagic v3

Dette prosjektet er en native Android-app for Peugeot e-2008 / PSA e-CMP.

## Viktigste forskjell fra webversjonen
Bluetooth Classic / SPP håndteres av Android direkte gjennom `BluetoothSocket`.
Appen trenger derfor ikke GitHub Pages, HTTPS eller Web Serial for å koble til ELM327.

## Funksjoner
- Bluetooth Classic / RFCOMM SPP
- Velg blant parede Bluetooth-enheter
- ELM327 init
- ISO 15765-4 / 11-bit / 500 kbit/s
- e-CMP BMS/VCU starterdatabase
- SOC
- SOH
- HV-spenning
- HV-strøm
- beregnet HV-effekt
- min/maks cellespenning og celle-delta
- batteritemperatur
- 12 V-spenning
- hastighet
- motor-RPM
- rå ELM327-terminal
- ATMA CAN monitor
- baseline/endringsvisning
- hendelsesmerking for gass, brems, regen, lading og gir

## Adapter
Adapteren må støtte Bluetooth Classic SPP, typisk ELM327 Classic.

Før første start:
1. Par ELM327 under Android → Innstillinger → Bluetooth.
2. Start appen.
3. Trykk `Frakoblet`.
4. Velg den parede adapteren.
5. Trykk `Initialiser`.
6. Start liveverdier eller CAN monitor.

## Bygg APK lokalt
Krever:
- JDK 17
- Android SDK platform 35 / build-tools 35
- Gradle 8.7

Kjør:
```bash
gradle assembleDebug
```

APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Bygg APK automatisk på GitHub
Prosjektet inneholder `.github/workflows/build-apk.yml`.

1. Last hele prosjektet til et GitHub-repository.
2. Åpne fanen **Actions**.
3. Kjør workflowen **Build Android APK**.
4. Last ned artifactet `e2008-can-debug-apk`.

## Merknad
Første versjon bruker read-only UDS/OBD og rå monitorering. Ingen UDS write/routine control/security access er lagt inn.

e-CMP signalene er en starterprofil og bør verifiseres mot logg fra bilen.

## Codemagic – bygg APK uten Android Studio
Denne versjonen inneholder `codemagic.yaml` i roten.

### Fremgangsmåte
1. Pakk ut ZIP-en.
2. Last **innholdet i mappen** til et Git-repository (for eksempel `Peugeot-Can`).
3. Opprett/logg inn på Codemagic.
4. Velg **Add application** og koble Git-repositoryet.
5. Velg repositoryet og la Codemagic finne `codemagic.yaml`.
6. Velg workflow **e-2008 CAN - Android APK**.
7. Trykk **Start new build**.
8. Når bygget er grønt, åpne **Artifacts** og last ned `app-debug.apk`.

Workflowen bruker Java 17, lager Gradle 8.7 wrapper automatisk hvis den mangler,
setter Android SDK-stien og kjører `assembleDebug`.

APK-en blir normalt laget her:
`app/build/outputs/apk/debug/app-debug.apk`


## v3 – Codemagic build-fiks

Denne versjonen bruker en eksplisitt kompatibel build-kjede:

- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Java 17
- compileSdk / targetSdk 35
- Android Build Tools 35.0.0

`codemagic.yaml` laster ned Gradle 8.7 direkte under bygget, så prosjektet er ikke
avhengig av at `gradlew` allerede finnes i repoet.

### På Codemagic
1. Erstatt filene i repoet med innholdet fra denne pakken.
2. Pass på at `codemagic.yaml` ligger helt i roten av repoet.
3. Trykk **Check for configuration file** hvis Codemagic ikke oppdaterer workflowen.
4. Start workflow: `e-2008 CAN - Android APK v3`.
5. Ved grønt build: åpne **Artifacts** og last ned `app-debug.apk`.
