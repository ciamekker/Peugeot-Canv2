# e-2008 CAN v22 – Build + Sniffer Fix

Bygger videre på v21 OEM Full BMS.

## Rettet byggefeil
MainActivity.java brukte to metoder som manglet:
- isSocketConnected()
- drainAvailable()

Begge er nå implementert.

## Rettet CAN Sniffer
`monitoring` ble tidligere satt til `true` før ELM-oppsettet.
`sendElmCommandBlocking()` setter monitorflagget til `false`, så ATMA-løkken kunne avsluttes direkte.

I v22:
1. Vanlige ELM-kommandoer kjøres først.
2. Protokoll settes opp.
3. Buffer tømmes.
4. `monitoring = true` settes rett før ATMA.
5. ATMA-streamen leses kontinuerlig.

Versjon 2.3.1 / versionCode 22.
